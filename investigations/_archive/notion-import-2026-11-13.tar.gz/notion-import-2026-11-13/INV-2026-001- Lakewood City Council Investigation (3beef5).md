---
source: notion
title: INV-2026-001: Lakewood City Council Investigation
notion_id: 3beef56cb23c81219ee7c0a6897df26b
type: note
status: migrated
created: 2026-11-14
---

**Case ID:** INV-2026-001  
**Status:** 🟡 Active Investigation  
**Priority:** HIGH  
**Opened:** August 16, 2026  
**Lead Investigator:** User
---
## ⚠️ Executive Summary
Investigation into Lakewood WA City Council members has uncovered **multiple significant conflicts of interest**:
### Critical Findings
1. **Paul Bocchi (Mayor)** - Employed by Pierce County while serving as city council mayor
2. **Patti Belle (Deputy Mayor)** - Employed by City of Kent while serving on Lakewood council  
3. **Philip Lindholm** - Real estate brokerage CEO making land use decisions
4. **Ryan Pearson** - Pierce County engineer reviewing developments affecting Lakewood
**Risk Level:** ELEVATED - Pattern of weak ethics enforcement or systematic disregard for conflict of interest norms.
---
## Council Members
<table header-row="true">
<tr>
<td>Name</td>
<td>Position</td>
<td>Conflict Rating</td>
<td>Key Issue</td>
</tr>
<tr>
<td>Paul Bocchi</td>
<td>Mayor</td>
<td>🔴 HIGH</td>
<td>Dual employment (Pierce County)</td>
</tr>
<tr>
<td>Patti Belle</td>
<td>Deputy Mayor</td>
<td>🔴 HIGH</td>
<td>Dual employment (City of Kent)</td>
</tr>
<tr>
<td>Philip Lindholm</td>
<td>Councilmember</td>
<td>🔴 HIGH</td>
<td>Real estate business interests</td>
</tr>
<tr>
<td>Ryan Pearson</td>
<td>Councilmember</td>
<td>🔴 HIGH</td>
<td>County development review role</td>
</tr>
<tr>
<td>Mike Brandstetter</td>
<td>Councilmember</td>
<td>🟡 MEDIUM</td>
<td>Multiple board positions</td>
</tr>
<tr>
<td>Ellen Talbo</td>
<td>Councilmember</td>
<td>🟡 MEDIUM</td>
<td>Planning industry ties</td>
</tr>
<tr>
<td>J. Trestin Lauricella</td>
<td>Councilmember</td>
<td>🟡 MEDIUM</td>
<td>Vague employment disclosure</td>
</tr>
</table>
---
## Evidence Summary
- ✅ 10 evidence items collected
- ✅ 9 sources verified
- ✅ Campaign finance records reviewed
- ✅ Business registries searched
- ⏳ Financial disclosures pending
- ⏳ Property records pending
---
## Next Steps
### Immediate (This Week)
- [ ] Search WA PDC financial affairs for all 7 members
- [ ] Review council meeting minutes for recusal records
- [ ] Identify major development votes since 2026
### Short-term (2 Weeks)
- [ ] Run username searches (sherlock)
- [ ] News archive research
- [ ] Public records request for Lauricella employer
### Medium-term (1 Month)
- [ ] Analyze voting patterns vs. personal interests
- [ ] Map campaign donors to city contractors
- [ ] Draft findings report
---
## Case Files
- **Main Case:** `INV-2026-001-lakewood-council.md`
- **Update Report:** `INV-2026-001-lakewood-council-update-20260816.md`
- **Location:** `~/.hermes/profiles/investigative-journalist/cases/`
---
## Sources
1. [cityoflakewood.us](http://cityoflakewood.us) - Official council bios
2. [pdc.wa.gov](http://pdc.wa.gov) - Campaign finance records
3. [piercecountywa.gov](http://piercecountywa.gov) - County employment records
4. [kentwa.gov](http://kentwa.gov) - City of Kent employment
5. [concordcounsel.com](http://concordcounsel.com) - Lindholm business
6. Ballotpedia - Election records
7. The News Tribune - Local news coverage
---
**Last Updated:** August 16, 2026 at 3:45 PM PDT  
**Next Review:** August 20, 2026
---
*This is a public records investigation. All information sourced from publicly available documents.*
<page url="https://app.notion.com/p/3bfef56cb23c818d8f81f5ce5ee422c5">INV-2026-001: Lakewood Council — Full Case Log</page>