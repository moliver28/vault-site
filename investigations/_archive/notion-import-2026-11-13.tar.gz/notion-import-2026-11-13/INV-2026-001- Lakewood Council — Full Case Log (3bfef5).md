---
source: notion
title: INV-2026-001: Lakewood Council — Full Case Log
notion_id: 3bfef56cb23c818d8f81f5ce5ee422c5
type: note
status: migrated
created: 2026-11-14
---

## Case Status
**INV-2026-001 \| 2026-08-16: Lakewood City Council Investigation**
Status: Active — All leads complete
**56 council meetings across 16 years (2010-2026). ONE recusal.** The Lakewood City Council has an institutional culture of zero recusal enforcement despite multiple members having direct employment and financial conflicts.
### Key Numbers
- 37 evidence items collected
- 8 NER pipeline runs completed
- 3 of 7 members employed by other governments
- 2 members with real estate/development conflicts
- 1 member whose employer funds his own CTO agency
### The 3 Explosive Angles
1. **Lindholm's podcast-donor feedback loop** — Producer is \$2,400 donor; guest is \$1,200 donor
2. **Belle sworn in by her boss** — Kent Mayor Dana Ralph administered her Lakewood oath
3. **Lauricella votes on own agency's budget** — CTO of city-funded South Sound 911
### Subject Conflict Ratings
- Bocchi (Mayor): HIGH — Pierce County employee, voted on county contracts
- Belle (Deputy Mayor): HIGH — Kent employee, sworn in by Kent Mayor
- Lindholm (Councilmember): HIGH — F-1 omits Concord Counsel income, developer-funded
- Pearson (Councilmember): HIGH — Voted on engineering regs he administers
- Brandstetter (Councilmember): MEDIUM — Only member to ever recuse (2010)
- Talbo (Councilmember): MEDIUM — Renton employee, 3rd dual-employment case
- Lauricella (Councilmember): HIGH — SS911 CTO votes on budget funding his agency
### Evidence Log
- E001-E010: Council bios, elections, employment verification
- E011-E020: Meeting minutes (56 total), F-1 filings, campaign finance, enforcement, podcast list
- E031-E037: Phase 4 supplemental — Belle sworn in by Kent Mayor, Lindholm podcast-donor loop, SS911 budget conflict
### Leads Status
- L001-L009: ALL COMPLETED
- L010 (Podcast-donor cross-ref): ACTIVE
- L011 (Lauricella budget vote): ACTIVE
- L012 (Belle-Kent-Lindholm triangle): ACTIVE
- L013 (Lindholm income verification): ACTIVE
### Next: Publication Phase
MVP: Lindholm profile (podcast-donor loop + F-1 omission + development votes)