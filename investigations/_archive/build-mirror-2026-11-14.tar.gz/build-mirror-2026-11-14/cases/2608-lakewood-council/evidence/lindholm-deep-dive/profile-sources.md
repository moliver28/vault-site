# Profile Sources — Verbatim Excerpts

**Case:** 2608-lakewood-council · **Subject:** Philip Michael Lindholm · **Captured:** 2026-11-13
**Purpose:** Custody artifact for the person-level profile. Each excerpt is copied from the source named. This file is hashed in `evidence-log.md` (E062–E078). Dynamic pages were captured as text on the date shown; re-verify before publication.

---

## 1. Puyallup Tribal Court Courtesy Bar List (2026-01-06)

**Source:** https://www.puyalluptribe-nsn.gov/wp-content/uploads/Puyallup-Tribal-Court-Courtesy-Bar-List_2026.01.06.pdf
**Header:** "This is a courtesy list for the public of Attorneys/Advocates admitted to practice before the Court. This list is voluntary, so not all inclusive."
**Row (verbatim):**

> Lindholm Philip M.
> 5409 100th St. SW, Box 39192 Lakewood, WA 98499 206-659-5960 Advocate 585

**Other relevant rows:** Jason M. Whalen, 7201 Holly Hedge Ln SW #2, Lakewood, WA 98499, Attorney 120. (Whalen is the mayor Lindholm succeeded and an endorser; the bar list shows he is also a tribal-court attorney.)

---

## 2. Pierce County 2025 Primary Voters' Pamphlet, p. 51

**Source:** https://www.piercecountywa.gov/DocumentCenter/View/147377/2025-Primary-VP
**Note:** The county prints candidate statements as submitted and does not verify them.

> # Philip Lindholm
> (253) 234-4686
> mail@votephilip.com
> votephilip.com
>
> **Elected Experience**
> First-time candidate; long-time leader.
>
> **Other Professional Experience**
> Air Force Captain; CEO of local small business; Lecturer at University of Washington; Development Researcher for BBC; Presenter for ITV; Tacoma Prosecutor's Office; Puyallup Tribe of Indians.
>
> **Education**
> Oxford University (doctorate, two master's degrees); Seattle University School of Law (JD in progress); University of Middlesex (master's); Central Washington University (two BAs); University of Washington Tacoma (BA in progress); Green River Community College (AA).
>
> **Community Service**
> Lakewood Planning Commission; Lakewood Rotary; Steilacoom Kiwanis; Mary Bridge Hospital; Pierce County Dispute Resolution Center; Continuum of Care Board; Point-in-Time Homelessness Count; Informed Citizen Podcast; TEDx Speaker.
>
> **Statement**
> I am running for City Council to build a better Lakewood for my family and yours. I envision Lakewood as a place our children don't want to leave and our seniors can afford to stay—a place where every chapter of life belongs.
>
> As a small-business CEO and Lakewood Planning Commissioner, I know how we can revitalize our downtown and effectively address homelessness, public safety, and growth. As a former Air Force officer, I will stand up for our military members and strengthen our city's bond with JBLM and Camp Murray. As a son, father, and former grief-group facilitator at Mary Bridge Hospital, I will be a bold advocate for our most vulnerable populations.
>
> I believe in collaboration and have earned strong bipartisan support from leaders across our community. I am endorsed by current and previous mayors—Jason Whalen, Don Anderson, and Doug Richardson—as well as Deputy Mayor Mary Moss and City Council Members Paul Bocchi and Ryan Pearson. I am also endorsed by former Sheriff Paul Pastor and former Police Chief Mike Zaro, School Board President Alyssa Anderson Pearson, past and present Rotary Presidents, and local business owners.

---

## 3. DVIDS — "Incoming Wing Chaplain eager to serve" (2017-01-29)

**Source:** https://www.dvidshub.net/news/221770/incoming-wing-chaplain-eager-serve
**Caption (verbatim):**

> Rev. Dr. Philip Lindholm, who will soon begin training to serve as the Wing Chaplain, talks with Airmen at a chapel service in the Wing Auditorium on January 29.

**Metadata:** Camp Murray, Washington, United States; 01.29.2017; Story by Senior Master Sgt. Michael White; 194th Wing.

---

## 4. The Cascadian — About page

**Source:** https://thecascadian.com/about/
**Excerpts (verbatim):**

> Welcome to **The Cascadian**, a community publishing platform for Western Pierce County where neighbors share stories, events, and ideas in their own words.

> **Co-founders:** *Philip Lindholm* and *Walter Neary*

> In 2025, Philip Lindholm ran for and won election to the same council. He was driven by the same concern and created *The Informed Citizen* podcast to spark dialogue and civic engagement. Now, Philip and Walter are joining forces to build *The Cascadian* as a 501(c)(3) nonprofit, uniting their shared belief that communities thrive when people have more information and more ways to be heard.

> **Editors:** *Walter Neary* and *Steve Dunkelberger*

> If members of our team publish on The Cascadian, they are publishing as individuals and not representing The Cascadian.

**Footer:** "Copyright © 2025 Cascadian Media, PO Box 39192, Lakewood, WA 98496."

---

## 5. The Seattle Times — Brier Dudley column

**Source:** https://www.seattletimes.com/opinion/pierce-county-news-site-debuts-meta-starts-paying-for-news-and-more
**Excerpts (verbatim):**

> A news website just launched in Pierce County but it doesn't plan to do original reporting, at least for the time being.

> The Cascadian will operate as an online bulletin board for the county's west side, including communities south of Tacoma. People and organizations may share news and announcements on the site at no charge.

> "We'd definitely like to get to the point where we are generating reports of government actions and editorial direction," said Walter Neary, co-founder of The Cascadian. "Right now, it's empowering the community — civic education."

> Now retired, Neary started The Cascadian with Phil Lindholm, a mediator and podcaster recently elected to the Lakewood City Council.

> The Cascadian is edited by Neary and Steve Dunkelberger, another veteran of The Lakewood Journal, with help from Neary's family.

> Neary said it cost around $6,000 to launch The Cascadian. It will operate as a nonprofit. It's aiming to generate revenue initially through donations and sponsorships.

---

## 6. ProPublica Nonprofit Explorer — Cascadian Media

**Source:** https://projects.propublica.org/nonprofits/organizations/412787967
**Excerpts (verbatim):**

> # Cascadian Media
> **Designated as a 501(c)(3)**
> **Category:** Arts, Culture and Humanities / Media, Communications Organizations
> **Donations to this organization are tax deductible.**
> **No Financial Data Available**

**Search result:** Cascadian Media | Lakewood WA | EIN **412787967** | NTEE **A30**.

---

## 7. HomeLight — Philip Lindholm agent profile

**Source:** https://www.homelight.com/agents/philip-lindholm-wa-109485
**Excerpts (verbatim):**

> # Philip Lindholm
> Real Estate Agent at **Terry Wise & Associates**
> Years of Experience **16**
> Transactions **50**
> Average Price Point **$354k**
> Single Family Homes **44**
> **3.7** (3 Reviews)

**Markets:** Lakewood, Tacoma, Auburn, Milton, Enumclaw, Federal Way, Port Orchard, Concrete, Kent, University Place.

---

## 8. YouTube — Dr. Philip Lindholm channel

**Source:** https://www.youtube.com/@drphiliplindholm/about
**Excerpts (verbatim):**

> **117K subscribers**
> **377 videos**
> **1,518,275 views**
> **Joined Sep 16, 2011**
> **United States**
> Discussing the issues that matter most with Dr. Philip LIndholm.

**Recent videos:**
- 31. "Should Immigration Be Easy?" with Nirvana's Krist Novoselic and Senator Yasmin Trudeau — 41K views, 1 month ago.
- 30. "Three Times Dead" with Recovering Addict Noah — 2,452 views, 2 months ago.
- 29. "Love OR Marriage" with Professor Stephanie Coontz — 42K views, 2 months ago.
- 28. "Can America Last?" with Lt. Gov Denny Heck and JMC President Hans Zeiger — 51K views, 4 months ago.
- 27. Human Trafficking is Hiding in Plain Sight — 3,175 views, 5 months ago.
- 26. "The Hard Questions of Homelessness" — 23K views, 6 months ago.

---

## 9. YouTube — The Informed Citizen production credits

**Source:** https://www.youtube.com/watch?v=hnRvCcKyOCs (description)
**Excerpts (verbatim):**

> Welcome to the Informed Citizen Podcast with Dr. Philip Lindholm. This series will feature visionary problem-solvers who are changing our world for the better.

> Credits:
> • Produced in partnership with **https://terrywisere.com**
> • Music: Sound and Vision, "This Party Bussin"
> • Editing & Post-Production: **Tony Wise at https://www.wisevideography.com**

**Note:** The exact URL in the description is `https://www.wisevideography.com/`; the captured text above preserves the visible label. The partnership URL is `https://terrywisere.com/`.

---

## 10. Pierce County LINX — Lawrence v. Lindholm (26-2-08192-7)

**Source:** https://linxonline.co.pierce.wa.us/linxweb/Case/CivilCase.cfm?cause_num=26-2-08192-7
**Excerpts (verbatim):**

> Pierce County Superior Court Civil Case 26-2-08192-7
> Case Title: JACOB LAWRENCE VS. PHILIP LINDHOLM
> Case Type: Consumer Protection Act
> Access: Public
> Track Assignment: Standard
> Jury Size: 12
> Dept Judge: 07 DIANA LYNN KIESEL

> LAWRENCE, JACOB — Plaintiff
> Attorney for LAWRENCE, JACOB: John Cummings, Atty for Plaintiff/Petitioner, Bar Number 40505
> LINDHOLM, PHILIP — Defendant
> Attorney for LINDHOLM, PHILIP: THOMAS F GALLAGHER, Atty for Defendant, Bar Number 24199

**Filings:** 04/29/2026 FILING FEE RECEIVED $290.00; CASE INFORMATION COVER SHEET (1 p.); ORDER SETTING ORIGINAL CASE SCHEDULE (1 p.); SUMMONS (2 p.); **COMPLAINT (62 p.)**; 05/11/2026 NOTICE OF APPEARANCE; 05/13/2026 RETURN OF SERVICE; 06/30/2026 NOTICE OF WITHDRAWAL AND SUB OF COUNSEL; 07/09/2026 NOTICE OF LITIGANT CHANGE OF ADDRESS; 08/13/2026 ANSWER AND AFFIRMATIVE DEFENSES (5 p.); 09/01/2026 LETTER FROM DEPARTMENT 7; 09/01/2026 JURY DEMAND - 12; 09/11/2026 PLAINTIFF'S LIST OF WITNESSES; 10/21/2026 PLAINTIFF'S LIST OF WITNESSES; 11/04/2026 AMENDED ANSWER AND AFFIRMATIVE DEFENSES (6 p.).

**Schedule:** Pretrial Conference week of 04/14/2027; Trial 04/28/2027 9:00; Discovery Cutoff 03/10/2027; Dispositive Pretrial Motions 03/31/2027.

---

## 11. Pierce County LINX — Lindholm v. State Farm (18-2-07177-7)

**Source:** https://linxonline.co.pierce.wa.us/linxweb/Case/CivilCase.cfm?cause_num=18-2-07177-7
**Excerpts (verbatim):**

> Case Title: PHILIP M LINDHOLM VS. STATE FARM INSURANCE COMPANY
> Case Type: Personal Injury
> Resolution: 07/23/2019 Settled by Arbitration
> Completion: 09/10/2019 Judgment/Order/Decree Filed

**Key filings:** 04/10/2018 COMPLAINT (6 p.); 07/30/2018 ANSWER; 08/03/2018 JURY DEMAND - 12; 07/23/2019 ARBITRATION AWARD; 08/19/2019 NOTICE OF SETTLEMENT OF ALL CLAIMS; 09/10/2019 ORDER OF DISMISSAL WITH PREJUDICE.

---

## 12. Pierce County LINX — name-search results

**Source:** https://linxonline.co.pierce.wa.us/linxweb/Search.cfm (superior and district name searches, 2010–2026)
**Results (verbatim summary lines):**

- Superior Criminal: "Your search returned 0 cases between 2010 and 2026 where the defendant's name is Lindholm, Philip."
- Superior Tax/Judgment: "Your search returned 0 cases between 2010 and 2026 where the litigant's name is Lindholm, Philip."
- Superior Civil: "Your search returned 2 Civil cases... LINDHOLM, PHILIP — 26-2-08192-7 — DEF — JACOB LAWRENCE VS. PHILIP LINDHOLM — 04/29/26; LINDHOLM, PHILIP M — 18-2-07177-7 — PLA — PHILIP M LINDHOLM VS. STATE FARM INSURANCE COMPANY — 04/10/18."
- District Criminal: "Your search returned 0 cases between 2010 and 2026 where the defendant's name is Lindholm, Philip."
- District Civil: "Your search returned 0 cases between 2010 and 2026 where the litigant's name is Lindholm, Philip."
- Superior Civil "Lochburn": 2 cases — LOCHBURN GARDENS PROPERTIES LLC v. BROWNIE STEVENS (10-2-15882-6, 12/14/10); LOCHBURN LANE LLC v. KAMALI E DUNNING (14-2-06652-5, 03/05/14).
- District Civil "Lochburn": 1 case — KENNEDY, LAKREESHA MARIE v. LOCHBURN LANE LLC (8Z906310C, 08/06/18), Lochburn Lane LLC as DEF.

**Caveat printed on the LINX results:** "The names provided in this list cannot be associated with any particular individuals without individual case research. Neither the court nor clerk makes any representation as to the accuracy and completeness of the data except for court purposes."

---

## 13. LinkedIn — certifications and publications

**Source:** https://www.linkedin.com/in/drphiliplindholm
**Excerpts (verbatim):**

> **Certifications**
> - Real Estate Broker, Washington State Department of Licensing (2011)
> - Board Certified Chaplain, National Association of Veteran Affairs Chaplains (2019)
> - Certified Mediator, Pierce County Dispute Resolution Center (2026)

> **Publications**
> - Review Levinas & Biblical Studies vol. 55, 4, 575, Society of Biblical Literature
> - Stu Ungar & Emmanuel Levinas, Philosophy (181-9), Vetus Test. (2006)
> - "The Struggle Within" in Metallica and Philosophy, ed. William Irwin (65-73), Open Court Press (2007)
> - Latter-day Dissent, Blackwell Press (2011)
> - Voyeur: Notes of Disquiet, Kofford Books (2011)

**Headline:** "Candidate for Lakewood City Council; Mediator; Veteran." **Location:** Lakewood, Washington. **Followers:** 901.

---

## 14. Lakewood Chamber of Commerce — Concord Counsel / Lindholm bio

**Source:** https://business.tacomachamber.org/list/member/concord-counsel-1253641
**Excerpts (verbatim):**

> **Concord Counsel**
> 705 S 9th St Tacoma WA 98405
> (253) 234-4686
> At Concord Counsel, we help individuals, families, and organizations navigate conflict without the stress and cost of litigation. Our tailored mediation process empowers you to move forward.

> **Dr. Philip Lindholm**
> Philip was a Rhodes Scholar finalist who graduated with his doctorate from Oxford after obtaining three master's degrees. He went on to lecture at Oxford and the University of Washington before serving as a Captain Chaplain for the United States Air Force. He later became CEO of a real estate brokerage and consulting firm while serving as a Lakewood Planning Commissioner. He is now CEO and Chief Mediator at Concord Counsel and candidate for the Lakewood City Council. He is a proud member of the Lakewood Rotary, Steilacoom Kiwanis, and previously volunteered for eight years as a grief group facilitator for Mary Bridge Hospital.

> 5409 100th St SW PO Box 39192 Lakewood WA 98499

---

## 15. Concord Counsel — homepage

**Source:** https://www.concordcounsel.com
**Excerpts (verbatim):**

> Dr. Philip Lindholm is the Founder and CEO of Concord Counsel. He brings to each matter a rare depth of perspective, shaped by his experience as a CEO, city councilmember, licensed real estate broker, barred member of several tribal courts, Air Force Captain, and grief group facilitator.

> **Mediation** — Concord Counsel provides mediation services designed to help parties resolve disputes in a constructive and cost effective manner.

> **Tribal Law** — At Concord Counsel, representation is provided in real estate and family law matters exclusively in certain tribal courts where appropriately barred.

> **Community Relations** — Concord Counsel provides bespoke community relations services to individuals and organizations trying to make an outsized impact in their community.

---

## 16. City of Lakewood — council biography

**Source:** https://cityoflakewood.us/city-council
**Excerpts (verbatim):**

> **Councilmember Philip Lindholm**
> Councilmember, Position 3
> Took office: 2026
> Term expires: Dec. 31, 2029
> City Hall: (253) 983-7705
> Cell Phone: (253) 401-6825
> Email: PLindholm

> Councilmember Philip Lindholm was elected to his first term on the Lakewood City Council in 2026.
> Philip is honored to serve as a Lakewood City Councilmember. Philip was a Rhodes Scholar finalist who earned his doctorate from Oxford University after completing three master's degrees. He went on to produce documentaries with the BBC and ITV, and lecture at Oxford and the University of Washington, before serving as a Captain in the United States Air Force.
> Philip transitioned out of the Air Force and into the corporate world, becoming CEO of a real estate brokerage and consulting firm, while also serving on the Lakewood Planning Commission. He is now the owner of small-business Concord Counsel where he works as Chief Mediator and member of the Puyallup Tribal bar, and he proudly volunteers with Lakewood Rotary after eight years as a grief-group facilitator at Mary Bridge Hospital.
> Philip delivered a TEDx talk titled "The Secret to a Meaningful Life" and hosts The Informed Citizen Podcast, which explores real-world solutions to the challenges facing our world.

---

## 17. The News Tribune — candidate survey (2025-07-18)

**Source:** https://www.thenewstribune.com/news/local/article310792280.html
**Excerpts (verbatim):**

> Philip Lindholm is the CEO of a small business and on the Lakewood Planning Commission. He was an Air Force captain, a lecturer at the University of Washington and development researcher for the British Broadcasting Corporation, among other professional, educational and community service experiences. Lindholm said his small business and planning commission experience means, "I know how we can revitalize our downtown and effectively address homelessness, public safety and growth."

> "I will stand up for our military members and strengthen our city's bond with JBLM and Camp Murray. As a son, father and former grief-group facilitator at Mary Bridge Hospital, I will be a bold advocate for our most vulnerable populations," he wrote in his statement. "I believe in collaboration and have earned strong bipartisan support from leaders across our community."

> Lindholm is endorsed by Whalen, in addition to former Lakewood mayors Don Anderson and Doug Richardson, in addition to deputy mayor Moss, council members Bocchi and Pearson, former police chief Mike Zaro, former Sheriff Paul Pastor, School Board President Alyssa Anderson Pearson, past and present Rotary presidents and local business owners, according to his statement. He has raised $24,845 on his campaign and spent $13,591, according to the PDC.

---

## 18. YouTube transcripts — TEDx and kickoff

**TEDx source:** https://www.youtube.com/watch?v=4bGdzDkmCBs
**Kickoff source:** https://www.youtube.com/watch?v=_B24Q5tGei8
**TEDx excerpt (auto-caption, verbatim):**

> [1] so our next speaker is Captain Philip Lindhome he currently serves as a captain chaplain for the Washington Air National Guard and his board certified through the National Association of Veterans Affairs... [18] captain Lynn home was a Rhodes Scholar finalist and graduated with his doctorate degree from Oxford University... [41] please help me welcome captain Phillip Lindholm good morning I want to tell you a secret which I learned in my very first years working as a hospital chaplain... [72] it turns out that death was my best teacher and it wasn't until working in the shadow of death in the hospital that I learned the secret to a meaningful life...

**Kickoff excerpt (auto-caption, verbatim):**

> [25] This year we lose Mayor Whan, Deputy Mayor Moss, and our city manager John Caulfield uh for city council. And that's over 40 years of combined experience. And this comes at a time when we face significant challenges in affordable housing and public safety and growth. [46] I believe I have the passion and the experience to lead on these issues. And that's why I'm announcing my candidacy for Lakewood City Council position three. [65] I want Lakewood's best days to lie ahead for both my family and for yours. [68] I envision a Lakewood where our children like my son don't want to leave.

---

## 19. The Cascadian columns

**Sources:** https://thecascadian.com/the-boy-on-the-bus; https://thecascadian.com/a-story-worth-telling/
**Excerpts (verbatim):**

> **The Boy on the Bus** — "Fifty two years ago, a small boy stepped onto a school bus crying. 'Mom said we are not going to have a Christmas.' The bus driver cried for two hours, and then she jumped into action. She gave that boy a Christmas and soon did the same for 25 more families. Caring for Kids was born." ... "Philip Lindholm is a mediator and Lakewood City Councilmember."

> **A Story Worth Telling** — "As a member of the Playhouse Board, I picked up the phone and called John Hall, president of Korum Ford. I explained the situation and asked if he might be willing to help. Before I had the chance to propose a sponsorship package, John said yes."

---

## 20. Wikipedia / DBpedia / Amazon / AllMusic — secondary biography

**Sources:** https://en.wikipedia.org/wiki/Philip_Lindholm; https://dbpedia.org/page/Philip_Lindholm; https://www.amazon.com/stores/author/B0050GEOE2/about; https://www.allmusic.com/artist/whiskey-n-rye-mn0003248720
**Key secondary claims (paraphrase, not verbatim):**

- Born December 10, Seattle; American public servant, singer-songwriter, academic.
- Left high school at 17; Green River Community College; Central Washington University high honors; Rhodes Scholar finalist; Oxford doctorate; master's in Judaism, Christianity, Islam; lecturer at Oxford and UW.
- BBC/ITV documentaries; *Latter-day Dissent*; *Voyeur*; TEDx 2019.
- Amazon: "Revd Dr. Lindholm subsequently served as a Captain Chaplain for the Washington Air National Guard. He is board certified by the National Association of Veterans Affairs and the Association of Professional Chaplains..."
- AllMusic: "Seattle's Whiskey n' Rye is a rootsy, Americana- and country-tinged rock outfit centered on the music of singer/songwriter, filmmaker, writer, and academic Philip Lindholm. A native of Seattle, Lindholm is a polymath..."

---

## 21. Pre-campaign personal site — philiplindholm.com (2013 capture)

**Source:** http://web.archive.org/web/20131210113452/http://www.philiplindholm.com/about/
**Excerpt (verbatim):**

> About
> Dr. Lindholm is a musician, author, and entrepreneur. He holds three masters degrees and graduated with a doctorate from the University of Oxford. During his graduate study, Philip traveled around the world as a filmmaker alongside some of the world's best talent, including the BBC, ITV, Scorsese, Maysles, & Holden. Philip then returned to the U.S. to lecture at the University of Washington Jackson School, start a band (Whiskey N' Rye), and found a series of successful businesses, including Stage 1 Studio & Rehearsal (now sold), University Place Press, & Oxford Tutoring Services. Philip is now a principal consultant and broker with The Lindholm Group, a managing member and filmmaker with 24/30 Cinema, **associate of Terry Wise & Associates**, and singer/songwriter with Whiskey N' Rye. He has published multiple book chapters, two full-length works (Voyeur & Latter-day Dissent), and his third book is currently underway.

**2013 homepage (verbatim):**

> Philip Lindholm › Musician. Author. Entrepreneur. … Singer/Songwriter for WHISKEY N' RYE Broker & Consultant for THE LINDHOLM GROUP Professional Photographer Published Author

---

## 22. Same site — "Consulting" page (updated 2025-03-05)

**Source:** http://web.archive.org/web/20131210113452/http://www.philiplindholm.com/consulting/ (the Wayback capture served a later, 2025-03-05 revision)
**Excerpt (verbatim):**

> CONSULTING
> Dr. Philip Lindholm serves as a fractional CEO and consultant for small business. With four advanced degrees and a diverse professional background, Dr. Lindholm specializes in driving significant growth through strategic initiatives. **In his role as CEO at Terry Wise & Associates, Dr. Lindholm effectively scaled operations and increased revenues significantly**, leveraging his expertise in strategic planning and market analysis. His approach is focused on implementing innovative solutions that sustain long-term business success and incorporating redundancies in a streamlined and low-cost way. He now has a portfolio of clients, including the **Tacoma Business Council**, where he advises on growth technological sustainability. His consulting is designed to deliver not only immediate results but also strategies for ongoing improvement and market adaptability.

> Media — Philip Lindholm brings a wealth of experience in media production and digital strategy, honed through working with major broadcasters like the BBC and ITV where he researched, produced, and presented content for mass television audiences. … Whether you're initiating a podcast, enhancing your email marketing, or developing a robust media strategy, Philip provides the insights and tools necessary for success.

---

## 23. DVIDS — full article text (2017-01-29)

**Source:** https://www.dvidshub.net/news/221770/incoming-wing-chaplain-eager-serve
**Excerpt (verbatim, from the article body):**

> CAMP MURRAY— Following a two-year search for a Wing chaplain, the 194th Wing will soon have a chaplain on staff. Rev. Dr. Philip Lindholm, currently serving as a chaplain for CHI Franciscan Health, has begun his service in the Washington Air National Guard and will soon begin the Air Force's training program for chaplains. In 2016, Lindholm was a member of 194th Wing student flight waiting for his Top Secret security clearance. He was getting ready for basic training, to be followed by intelligence courses, so that he could be an enlisted member of the 194th Intelligence Squadron. Then, a new opportunity came his way. Instead of entering the intelligence field, Lindholm will be attending Commissioned Officer Training at Maxwell Air Force Base, Alabama before participating in a Chaplains' course at Fort Jackson, South Carolina to become the 194th Wing's new Chaplain.

> Lindholm grew up in Seattle. Growing up, sports was a huge part of his childhood, which included playing baseball and football at **Decatur High School in Federal Way**. His life started to slowly turn when he discovered a love for books. He spent more time after school with his nose in a book than on the field. He participated in the **Running Start program at Green River College**. He attended **Central Washington University** … [t]his turn was concerning to his parents as they worried about his future financial stability, he said. Lindholm was considered for the Rhodes scholarship, and he expected to win it. His life took a sobering turn when he didn't make the final selection. He applied to Harvard and Oxford University in England. At the time he had not received any money offers from Oxford, but Harvard offered an incentive. Then, during new student orientation at Harvard, there was a surprising yet welcomed turn, because he received funding from Oxford. Eventually, Lindholm earned three masters degrees, one each in Jewish, Christian, and Islamic studies.

> When he is not spending time with his **wife Lori and son Declan**, or doing volunteer work, his spare time …

---

## 24. Wikipedia — page text and photo caption

**Source:** https://en.wikipedia.org/wiki/Philip_Lindholm; image https://commons.wikimedia.org/wiki/File:Philip_Lindholm_Speaking.jpg
**Page text (verbatim, opening):**

> Philip Michael Lindholm (born December 10) is an American public servant, singer-songwriter, and academic from Seattle, Washington, United States. He is best known as the author of Latter-day Dissent and for playing the lead role in the BBC's murder mystery Who Murdered Warren Taylor, presenting ITV1's The Grail Trail: In Pursuit of the Da Vinci Code, creating and researching ITV1's The Muslim Jesus, and as the lead singer-songwriter for Whiskey N' Rye. In 2019, Lindholm gave a TEDx talk entitled "The Secret to a Meaningful Life."

**Key absence:** the page does **not** mention Lakewood, the city council, the 2025 campaign, or Concord Counsel. It is the academic/chaplain biography, not the council biography.

**Photo caption (Commons):**

> Dr. Philip Lindholm addressing an audience of Air Force members at Camp Murray
> DateTimeOriginal: 2019-12-07 17:18:40
> Artist: Kimballdonald
> License: CC BY-SA 4.0

---

## 25. Facebook posts — family and Makah court (self-published)

**Source:** https://www.facebook.com/drphiliplindholm (public page; post snippets via search)
**Excerpts (verbatim snippets):**

> "In Makah tribal court today. Their approach to justice is so unique and powerful … My son and his father said it was the best salmon they'd ever had! A true throwback to a beautiful corner of the Pacific Northwest."

> "It depends on what the husband and wife agreed on. My wife and I agreed I would work outside the home to bring in the income while she …"

**Use:** confirms the subject has a wife and a son and has appeared in Makah tribal court; does not name the wife or son.

---

## 26. Family-name public profiles (circumstantial)

- **Lori Lindholm, LICSW** — A Healing Place NW Counseling, Lakewood, WA; NPI 1336872043; UW MSW 2016; hospice/palliative/grief work. Public professional site: https://www.ahealingplacenw.com. The 2017 DVIDS article names the chaplain's wife as Lori. This is consistent with one household, but the site does not name her husband.
- **Declan Lindholm** — public racing blog/Instagram (`declan_lindholm_racing`); described as a student/league racer. The 2017 DVIDS article names the chaplain's son as Declan. This is consistent, but the public profiles do not name his father.

**Privacy note:** these are public professional/social profiles; do not publish addresses, schools, or other personal details about family members. Use only to corroborate the identity internally.

---

## 27. OpenLibrary — birth year data point

**Source:** https://openlibrary.org/search/authors.json?q=Philip%20Lindholm
**Record:** "Philip Lindholm 1980 OL6852128A."
**Caveat:** OpenLibrary birth years are user-contributed and not authoritative. Use only as a data point; do not publish without a vital record or a second authority file.
