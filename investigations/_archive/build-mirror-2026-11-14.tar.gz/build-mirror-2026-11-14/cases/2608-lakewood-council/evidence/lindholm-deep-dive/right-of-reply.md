# Right of Reply — Philip Lindholm

**Case:** INV-2026-001 · **Status:** DRAFT — not sent
**To:** Philip Lindholm, Lakewood City Council, Position 3
**Channels:** plindholm@cityoflakewood.us (official); 6000 Main Street SW, Lakewood, WA 98499
**Subject:** Questions before publication — Lakewood council record, business relationships, and media interests

Dear Councilmember Lindholm,

I am preparing a profile of you that will discuss your public record and your broader professional, business, and media footprint. It will cover your votes on the city's rental-housing rules, your abstention on the abatement contract for 5105 Solberg Drive SW, your business and property interests, your tribal-court practice, your podcast, and your role at The Cascadian. I am writing to give you a fair and specific opportunity to respond to the factual assertions I intend to make. Nothing in this letter is a conclusion about your motives; it is a list of the records I have and the questions they raise.

The records I have reviewed include your 2025 and 2024 Personal Financial Affairs Statements (PDC statements 132557 and 122447), the May 4, 2026 council minutes and video, the April 6, 2026 council minutes, video, and staff report, the Pierce County Assessor-Treasurer parcel records for 8814-8815 Lochburn Lane SW, 107-109 Lake Louise Dr SW, 9908 Meadow Rd SW, and 5105 Solberg Dr SW, your campaign contribution filings, the 2025 Pierce County Primary Voters' Pamphlet, the Puyallup Tribal Court Courtesy Bar List (January 6, 2026), the Pierce County Superior Court docket in *Lawrence v. Lindholm* (No. 26-2-08192-7), The Cascadian's About page and your columns, the published credits for *The Informed Citizen* podcast, and HomeLight's agent profile.

Please respond to the following questions. If any factual assertion below is wrong, please tell me specifically what is wrong and what the correct fact is.

1. **Ownership.** Your 2025 F-1 reports 84% ownership of 8814-8815 Lochburn Lane SW Lakewood, LLC, and 100% ownership of Wyoming Housing Holding Company and Washington Ventures Management. It lists 8814-8815 Lochburn Lane SW, 107-109 Lake Louise Dr SW, and 9908 Meadow Rd SW as your real estate. Please confirm which of these properties are rented to tenants, how many units each contains, and whether any are owner-occupied or vacant.

2. **The May 4 vote.** On May 4, 2026, Ordinance 849 carried; you are not recorded in opposition. The ordinance amended LMC Chapter 5.60 and added a self-certification option and an ADU exemption. Did you disclose to the council, the city attorney, or the city manager that you own rental property in Lakewood before that vote? If so, when and in what form?

3. **Ethics advice.** Did you seek an advisory opinion or written guidance from the city attorney or anyone else about whether your rental ownership created a conflict on Ordinance 849? If so, please provide the date and the substance of the advice.

4. **Your statement in the debate.** The video records you saying, "I've been a licensed real estate professional for 16 years now," and describing "personal experience with the rental safety program." Were you speaking from your experience as a Lakewood landlord? Did you intend the public to understand that you own rental property in the city?

5. **The Wise business relationship.** Your 2025 F-1 lists Terry Wise & Associates under the business-customer section of Washington Ventures Management, for "Consulting." The PDC describes that section as payments of $12,000 or more. Please confirm the date(s) and amount(s) of those payments, and whether they were made in 2025.

6. **Your statement to the council.** On April 6, 2026, you said: "I need to disclose that I do not have a professional relationship with Mr. Wise, but I do have a long-standing friendship and former colleague of mine." Given the F-1 entry described in question 5, what did you mean by "I do not have a professional relationship"? Were you referring only to the Solberg matter, or to all business relationships with Mr. Wise?

7. **The office sale.** Your F-1 reports that you sold 705 S 9th St, Suite 102, Tacoma — the Concord Counsel address — to Terry Wise for $200,000–$499,999. Please confirm the sale date, the price, and whether Concord Counsel continues to occupy the suite or pays rent to Mr. Wise.

8. **The Solberg contract.** Did you discuss the 5105 Solberg abatement contract, the owner's situation, or the timing of the contract with Mr. Wise or Ms. Michelle Le outside the public meeting? If so, when and what was discussed?

9. **The abstention.** You abstained on Motion 2026-25. The minutes do not record your reason; the video records your friendship with Mr. Wise. Was there any other reason for the abstention — for example, a business relationship with the owner, a property interest, or a request from the owner?

10. **Other properties.** Do you own, directly or through any entity, any other rental property in Lakewood that is not listed on your 2025 F-1?

11. **The operating name.** Your F-1 lists "Community for Philip Lindholm" as the operating name of Wyoming Housing Holding Company. That is also the name of your campaign committee. Is that a filing error, or does the company operate under that name? If it is an error, have you corrected it with the PDC?

12. **Concord Counsel.** Your campaign and city bios describe you as CEO of Concord Counsel. Concord Counsel is not listed as a business association on your F-1. Is Concord Counsel a trade name of Washington Ventures Management, a separate business, or inactive? If it is a separate business, why is it not listed?

13. **The Lawrence lawsuit.** Please confirm that you are the defendant in *Jacob Lawrence v. Philip Lindholm*, Pierce County Superior Court No. 26-2-08192-7, and describe the nature of the dispute in your own words. Is the plaintiff the same Jacob Lawrence listed as a private note receivable on your 2025 F-1? If not, please explain.

14. **The Cascadian.** You are listed as a co-founder of The Cascadian with Walter Neary. What is your current role — founder, board member, columnist, adviser, or none? Do you participate in editorial decisions or in coverage of the city council? How does the outlet disclose your council role and its shared PO Box with your campaign?

15. **The podcast production partnership.** *The Informed Citizen*'s YouTube description says it is produced in partnership with terrywisere.com and edited by Tony Wise. Your F-1 and campaign filings report $200 in-kind from Terry Wise & Associates for podcast production. Please describe the partnership, who pays for production, and how the $200 in-kind value was calculated.

16. **The “no professional relationship” statement.** On April 6, 2026, you told the council you had no professional relationship with Mr. Wise. Your F-1 lists a consulting payment from Terry Wise & Associates; HomeLight lists you as an agent at his brokerage; your podcast is produced in partnership with his company. Please reconcile those records with your statement. Did you mean only that you had no current professional relationship on the Solberg matter?

17. **Tribal court admissions.** The Puyallup Tribal Court lists you as an Advocate (Bar No. 585). Please confirm your admissions in Swinomish and Makah, the dates, and whether you are admitted as an attorney or an advocate in each. Are you currently enrolled at Seattle University School of Law?

18. **Tacoma Prosecutor's Office and Puyallup Tribe.** The 2025 voters pamphlet lists “Tacoma Prosecutor's Office” and “Puyallup Tribe of Indians” as professional experience. Please describe those roles, dates, and whether they were legal, policy, administrative, or internship positions.

19. **Current brokerage.** Are you currently licensed and affiliated with Terry Wise & Associates, or another brokerage? Please provide the current Department of Licensing status and firm.

20. **The rental portfolio and tenant disputes.** Please confirm the full list of rental properties and the number of units in each. Have any tenant disputes, eviction filings, or code-enforcement complaints been filed against the Lochburn LLC or any other entity you control? Are you aware of the 2018 *Kennedy v. Lochburn Lane LLC* case, and is that entity related to your current LLC?

21. **The Cascadian's nonprofit governance.** Who serves on the board of Cascadian Media? Does the board include any city officials or campaign contributors? Will the outlet publish a disclosure when it covers you or your votes?

22. **Podcast revenue and in-kind support.** Does the YouTube channel or podcast generate advertising, sponsorship, membership, or other revenue? If so, how is it reported on your F-1, and who owns the revenue?

23. **Identity confirmation.** Your official bio, the 2017 DVIDS article about the 194th Wing chaplain, and the pre-campaign philiplindholm.com site describe the same Oxford/film/music/real-estate career. Please confirm that you are the Rev. Dr. Philip Lindholm named in the 2017 DVIDS article and that the 2013 philiplindholm.com biography is yours. If any of those records belong to a different person, please identify which.

I intend to publish after a reasonable reply period. Please respond within **10 business days** of the date of this letter. If I do not hear from you, I will describe the efforts I made to reach you and will report that you did not respond. If you respond, I will verify any factual counter-claims before publication and will include your response fairly.

You may respond by email or in writing to the address above. If you would prefer to speak by phone, please tell me a time and a number.

Sincerely,

Michael Oliver
Investigative journalist
[contact channel]

---

**Transmission log (to be completed):**
- Attempt 1: ___ date/time, channel, proof
- Attempt 2: ___ date/time, channel, proof
- Attempt 3: ___ date/time, channel, proof
- Attempt 4: ___ date/time, channel, proof
- Attempt 5: ___ date/time, channel, proof

**Response:** ___
