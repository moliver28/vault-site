# The Landlord on the Council — Philip Lindholm Deep Dive

**Case:** INV-2026-001 · 2608-lakewood-council
**Subject:** Philip Lindholm, Lakewood City Council, Position 3
**Date:** 2026-11-12
**Status:** Reporting complete; right of reply pending; not for publication until the reply window closes
**Standard:** Every factual sentence below is tagged F (fact), A (allegation), or I (interpretation). The claim-by-claim grades are in `verification-matrix.md`.

---

## 0. The story in one paragraph

Philip Lindholm ran as the reform candidate and took office in January 2026. He is also a licensed real estate broker who owns rental property through LLCs. His 2025 financial disclosure lists 84% ownership of the LLC that owns an apartment complex on Lochburn Lane in Lakewood — a listing describes it as 18 units — 100% ownership of a real estate holding company that lists a duplex at 107-109 Lake Louise Drive, and a $1 million-plus home on Meadow Road. On May 4, 2026, the council adopted Ordinance 849, which rewrote Lakewood's rental housing licensing and inspection rules, including a new self-certification option and an exemption for accessory dwelling units. Lindholm is not recorded in opposition; he voted to keep the self-certification provision. No disclosure of his rental portfolio appears in the public minutes or video. A month earlier, he abstained on a $71,181.85 city abatement contract for a property whose owner was represented by his friend and former colleague, land-use consultant Terry Wise. He told the council: "I do not have a professional relationship with Mr. Wise." His 2025 F-1, filed two weeks before that statement, lists Terry Wise & Associates in the section for business customers that paid his company $12,000 or more, for "Consulting." The official minutes summarize Michelle Le as a "Lakewood resident" speaking about "her experience in residential real estate"; the video shows her saying, "I'm the owner of the property at 5105 Solberg Drive Southwest in Lakewood." The case is a window into how a part-time council with no ethics board polices its own conflicts — and how the public record only shows the full picture when minutes, video, campaign data, and financial disclosures are read together.

---

## 1. Hypothesis and falsification test

**Hypothesis:** Lindholm voted on Lakewood rental-housing policy while owning a material rental portfolio, with no disclosure of that ownership appearing in the public record; and in a separate contract vote he described his relationship with a conflicted party in a way that his own financial disclosure contradicts.

**What would falsify it:**
- A written conflict disclosure or city attorney opinion showing he disclosed the rental ownership before the May 4 vote.
- Evidence that the Lochburn LLC's units are not rentals (owner-occupied, vacant, or non-residential).
- Evidence that the Terry Wise & Associates payment was outside the 2025 reporting period and the relationship had ended before April 6, 2026.
- A recorded statement in which Lindholm disclosed the Wise consulting relationship to the council.

None of those has been found. Each is in the right-of-reply letter.

---

## 2. What the record shows

### 2.1 The portfolio

**F.** Lindholm's 2025 F-1 (statement 132557, filed 2026-03-23, period 2025-01-01 to 2025-12-31) reports three business associations:

| Entity | Ownership | Description | WA property reported |
|---|---|---|---|
| Wyoming Housing Holding Company (operating name: "Community for Philip Lindholm") | 100% | Real Estate Activities | 107-109 Lake Louise Dr, Lakewood; 9908 Meadow Rd SW, Lakewood |
| Washington Ventures Management | 100% | Real Estate Activities | none |
| 8814-8815 Lochburn Lane SW Lakewood, LLC | 84% | Real Estate Activities | 8814-8815 Lochburn Lane SW, Lakewood |

**F.** The Pierce County Assessor-Treasurer lists parcel 0220353064 at 8814 Lochburn Ln SW under the taxpayer name **8814-8815 Lochburn Lane Southwest Lakewood LLC**. A Redfin listing describes the property as an 18-unit apartment complex — two buildings, 8 and 10 units, built 1956 — last sold for $1.85 million in 2018. The assessor confirms the LLC as taxpayer; the unit count is the listing's, not an assessor count. Current listings advertise units from about $1,000 to $1,161 per month.

**F.** The assessor lists 107-109 Lake Louise Dr SW (parcel 4615000950) under **Wyoming Woopie LLC TTEE of 107 to 109 Lake Trust**. The property is a duplex (4 bedrooms, 2 baths, 1,374 sq ft). An apartments.com listing advertises 103-109 Lake Louise as a rental; the listing covers a range that includes his address, but the specific unit's rental status is not independently verified. Lindholm's F-1 lists 107-109 as his real estate and lists Wyoming Housing Holding Company as 100% his.

**F.** The assessor lists 9908 Meadow Rd SW (parcel 5030000900) under **9908 Meadow Rd SW Lakewood LLC**; the F-1 lists the property as his, assessed at $1 million or more. This appears to be his residence, not a rental.

**F.** The F-1 also reports sales: 1223 S J St, Tacoma (a 5+ unit apartment building, sold to 1223 S J St LLC; Redfin records the sale at $1.385 million on December 6, 2024); 705 S 9th St Suite 102, Tacoma (the Concord Counsel office suite, sold to **Terry Wise** for $200,000–$499,999); and 520 Buena Vista Ave, Fircrest (sold to Andy Tran).

**I.** The Lochburn building is the strongest direct tie: the LLC name matches the property address, the F-1 reports 84% ownership, and the assessor confirms the LLC as taxpayer. The Lake Louise duplex is also a rental, but the record owner is a trust/LLC; the F-1 supplies the beneficial ownership link.

### 2.2 The rental-housing vote

**F.** On May 4, 2026, the Lakewood City Council adopted Ordinance 849, amending LMC Chapter 5.60. The ordinance:
- replaces "rental-housing complex" with "rental housing unit" so the licensing/registration requirement applies to all rental properties, not just complexes of five or more units;
- separates licensing exemptions from inspection exemptions;
- removes the program exemption for transitional housing and shelters;
- reduces the new-construction inspection exemption from 10 years to 5;
- adds a **self-certification option** at 5.60.080(C): "A rental housing owner may provide self-certification that their rental property is in compliance with the requirements of this title in lieu of a certificate of inspection";
- adds an **ADU exemption** at 5.60.025(A)(7)/I for accessory dwelling units on the same lot where the owner lives on site.

**F.** The ordinance carried on a voice vote. The minutes record: "VOICE VOTE WAS TAKEN ON ORDINANCE NO. 849 AS AMENDED AND CARRIED WITH COUNCILMEMBER BRANDSTETTER VOTING IN OPPOSITION." The record does not individualize the ayes; Lindholm is not recorded in opposition. He did cast an individual vote to keep the self-certification provision: the motion to delete it failed with "COUNCILMEMBER LINDHOLM, PEARSON, DEPUTY MAYOR BELLE AND MAYOR BOCCHI VOTING IN OPPOSITION." He also seconded the ADU amendment (minutes: "SECONDED BY COUNCILMEMBER LINDHOLM. ROLL CALL VOTE WAS TAKEN AND CARRIED").

**F.** During the debate, Lindholm said on the record: "I've been a licensed real estate professional for 16 years now." He also said: "Having personal experience with the rental safety program — I don't know if you guys have it — it doesn't always make the property safer but it always raises the cost every single time."

**F.** Neither the minutes nor the video record a disclosure that Lindholm owns rental property in Lakewood, or an abstention on Ordinance 849.

**I.** The vote is a policy vote, not a contract vote. RCW 42.23's "beneficial interest" prohibition is aimed at specific contracts; a general ordinance is a different legal question. The story is not "he broke the statute." The story is that the councilmember with the largest disclosed rental portfolio in the room voted on the rules that govern it, described himself as a real estate professional, and did not tell the public he was speaking from personal experience as a landlord. That is an appearance-and-disclosure problem, and it is exactly the kind of problem Lakewood's ethics code is supposed to address.

### 2.3 The Solberg abstention and the Wise relationship

**F.** On April 6, 2026, the council considered Motion 2026-25: a $71,181.85 abatement contract with DP Excavation, Inc. for 5105 Solberg Dr SW. Lindholm asked that the item be pulled from the consent agenda. He then abstained. The motion passed 6–0 with his abstention.

**F.** The staff report describes the property: a 28,328 sq ft parcel with a 7,380 sq ft commercial structure in the NC2 zone; a long history of illegal residential use dating to 2015; 12 people found living in the commercial structure in June 2024; a July 23, 2024 Findings and Order; a June 6, 2025 Warrant of Abatement; a November 6, 2025 Second Warrant; nine households relocated with $30,019 advanced by the city and repaid by the owner on July 2, 2025; repair estimate $349,677.60 vs. demolition estimate $135,423; DP Excavation the low bidder at $71,181.85.

**F.** The property's taxpayers of record are **Tran Sinh V** and **Le Michelle T** (parcel 0219114191). In public comment, Michelle Le said: "I'm the owner of the property at 5105 Solberg Drive Southwest in Lakewood." She described herself as a residential real estate investor who bought the property to provide attainable housing and said the arrangement with a pastor/tenant "didn't work out."

**F.** **Terry Wise** also spoke. He said: "I'm a land use consultant and I'm representing a client that owns property at 5105 Solberg Drive Southwest." He said he was contacted the previous Thursday afternoon and had Friday and the meeting day to review the matter.

**F.** Lindholm said on the record: "I need to disclose that I do not have a professional relationship with Mr. Wise, but I do have a long-standing friendship and former colleague of mine." He called Wise "incredibly capable" and said Wise had "approximately three business days on this project." He suggested waiting two weeks "to see if Mr. Wise can hammer out a mutually agreeable timeline with city staff," then said: "I would expect to abstain from any vote on this."

**F.** Lindholm's 2025 F-1 lists **Terry Wise & Associates** under the business-customer section of his wholly owned company, **Washington Ventures Management**, with the purpose "Consulting." The PDC's F-1 instructions describe that section as "Payments Received From Business Customers (>$12,000)": businesses that paid $12,000 or more in the aggregate for services or products provided by the entity. The 2024 F-1 (statement 122447, filed 2025-01-11) lists the same relationship.

**F.** The F-1 also reports that Lindholm sold the office suite at 705 S 9th St, Suite 102, Tacoma — the Concord Counsel address — to **Terry Wise**, for $200,000–$499,999.

**I.** This is the central disclosure gap. Lindholm disclosed a friendship and a former colleague relationship. He did not disclose that Wise's firm is listed on his own financial disclosure in the business-customer section, which reports payments of $12,000 or more, for consulting. He may have meant "no current professional relationship on this project," and the payment may predate the statement. But the public record he filed two weeks earlier says otherwise, and the council did not hear it.

### 2.4 The campaign money

**F.** Lindholm raised $33,805.02 and spent $33,000.41 in the 2025 council race. The verified floor from real estate, landlord, and construction interests is **$6,300**:
- Terry Wise: two $1,200 contributions on 2025-03-24 ($2,400); Terry Wise & Associates: $200 in-kind on 2025-08-18.
- Landlord Solutions, Inc.: $1,200 (2025-04-23).
- Master Builders Association of Pierce County: $1,200 (2025-07-30).
- Washington Association of Realtors PAC: $500 (2025-10-17).
- Rémy Claude, self-described developer: $1,000 (2025-01-22).

**Unverified classification (do not count in the floor):** Stonegate Associates LLC ($2,000) — the name matches a New Jersey security-consulting firm; the Lakewood Stonegate Apartments is managed by Dobler Management, and no source ties the donor to it. Capital Ventures ($2,400) and McKinley Sands ($2,400) — Sands McKinley is a family-law attorney and founder of McKinley Irvin; no source establishes Capital Ventures as a real estate developer.

**F.** Terry Wise & Associates is credited on Lindholm's podcast, "The Informed Citizen," for editing and post-production (credit: "Tony Wise at Terry Wise & Associates"). The campaign reported $200 in-kind from the firm; the filing does not describe the in-kind purpose, and the podcast credit is a separate record.

**I.** The campaign-finance pattern is not proof of a quid pro quo. It is a map of who invested in the candidate. The story is that the same network — Wise, Landlord Solutions, the Master Builders, realtor PACs — had business before the council in the first half of 2026: the rental-housing ordinance, the ADU exemption, and the Solberg abatement.

### 2.5 The records gap

**F.** The official April 6 minutes say: "Michelle Le, Lakewood resident, spoke about her experience in residential real estate and the contract for abatement of property at 5105 Solberg Drive SW." They do not say she is the property owner. The video shows she said: "I'm the owner of the property at 5105 Solberg Drive Southwest in Lakewood."

**F.** The minutes record Lindholm's abstention but not his stated reason. The video contains the reason: his friendship with Wise. The minutes mention Terry Wise in the public-comment section but do not connect him to Lindholm's abstention.

**I.** This is the systemic finding in miniature. Lakewood's official record is a summary. The conflict disclosure exists only in the video. A resident who reads the minutes cannot see the relationship; a resident who watches the video hears a friendship but not the $12,000 consulting entry in the F-1. The public has to assemble the picture from four different records — minutes, video, PDC filings, and assessor data — to see what happened.

---

## 3. Verification summary

Full matrix: `verification-matrix.md`.

| # | Claim | Grade |
|---|---|---|
| 1 | Lindholm's 2025 F-1 reports 84% ownership of the Lochburn LLC and 100% of two real estate entities | **Verified** (F-1 + assessor) |
| 2 | The Lochburn LLC owns the apartment complex at 8814-8815 Lochburn Ln SW; a listing describes it as 18 units | **Corroborated** (assessor taxpayer + Redfin; unit count not independently counted) |
| 3 | Lindholm's F-1 lists a duplex at 107-109 Lake Louise Dr SW; the building is advertised as a rental, but the specific unit's rental status is unverified | **Corroborated** (F-1 + assessor; rental listing covers 103-109) |
| 4 | Ordinance 849 carried on a voice vote; Lindholm is not recorded in opposition; he voted to keep the self-certification provision | **Verified** (minutes) |
| 5 | No disclosure of his rental ownership or recusal appears in the May 4 minutes or video | **Verified absence** (public record only) |
| 6 | He said he has "personal experience with the rental safety program" and is a 16-year real estate professional | **Verified** (video) |
| 7 | He abstained on the Solberg abatement contract | **Verified** (minutes + video) |
| 8 | He said he has no professional relationship with Terry Wise | **Verified** (video) |
| 9 | The F-1's business-customer section, which reports $12,000+ payments, lists Terry Wise & Associates for consulting | **Corroborated** (F-1 JSON + PDC instructions); exact date/amount unverified |
| 10 | Terry Wise represented the Solberg property owner | **Verified** (video) |
| 11 | Michelle Le owns 5105 Solberg | **Verified** (assessor + video) |
| 12 | The official minutes omit Le's ownership disclosure | **Verified** (minutes vs. video) |
| 13 | Lindholm received $2,600 from Terry Wise and his firm | **Verified** (PDC) |
| 14 | "Pay-to-play" or a quid pro quo | **Speculative — not supported** |
| 15 | The $200 in-kind podcast production was undervalued | **Speculative — no fair-market-value evidence** |
| 16 | The original case-file claim that the April 6 abstention was on rental housing | **Misleading — corrected to the Solberg abatement contract** |
| 17 | The original case-file claim that the F-1 shows "zero business income" | **Misleading — the F-1 discloses three real estate entities; the narrow issue is Concord Counsel not being named** |

---

## 4. What we can say, and what we cannot

**Can say:**
- Lindholm owns rental property in Lakewood through LLCs; the rental-housing ordinance carried with no disclosure of that ownership appearing in the public minutes or video.
- He described himself in the debate as a licensed real estate professional with personal experience of the rental safety program.
- He abstained on the Solberg contract and disclosed a friendship with Wise.
- The F-1's business-customer section, which reports payments of $12,000 or more, lists Wise's firm for consulting, and he did not mention that to the council.
- The official minutes omit both Le's ownership disclosure and Lindholm's reason for abstaining; the video contains both.

**Cannot say (yet):**
- That Lindholm cast a final aye on Ordinance 849. The final vote was a voice vote; the record shows only that he is not recorded in opposition. What is verified is his individual vote to keep the self-certification provision.
- That Lindholm violated RCW 42.23 by voting on Ordinance 849. The statute targets specific contracts; a general ordinance is a different question. The city's ethics code may require disclosure, but no enforcement mechanism or written opinion has been found.
- That the Wise consulting payment was made in 2025 with certainty. The form covers 2025, but the public JSON lacks the date and amount, and the field mapping is an interpretation of the schema. The filed form and Lindholm's answer will resolve it.
- That the $200 in-kind podcast figure was undervalued. No fair-market-value evidence.
- That Michelle Le concealed her ownership. The video shows she disclosed it; the minutes omitted it.
- That the Solberg abstention was improper. It was the appropriate call. The issue is the completeness of the stated reason.

---

## 5. The defense's counter-argument, written into the file

**On the rental vote:** "Ordinance 849 is a policy ordinance of general application. It does not name my client or his properties. RCW 42.23 prohibits a beneficial interest in a specific contract; it does not require a councilmember to recuse from every policy vote that touches an industry he works in. If it did, no landlord, developer, realtor, or tenant could ever vote on housing policy. My client disclosed his real estate interests on his F-1, as the law requires. He did not hide them."

**On the Wise relationship:** "Mr. Lindholm disclosed a long-standing friendship and former colleague relationship on the record and abstained. The F-1 entry is a business-customer category; it does not establish that Mr. Wise paid my client in 2025, and it does not establish an ongoing professional relationship. 'I do not have a professional relationship' meant no current business relationship on the Solberg matter. The abstention was the conservative, ethical choice."

**On the minutes:** "Minutes are summaries, not transcripts. The video is the official record of the discussion. Ms. Le identified herself as the owner in her comment. The city did not conceal anything."

**On the campaign money:** "Contributions from realtors, landlords, and builders are legal and disclosed. My client's platform supported housing supply and ADUs. There is no evidence of a quid pro quo."

**What survives the defense:** The vote on rental rules while owning 18 units, without disclosure, is a fact. The F-1's $12,000+ business-customer entry contradicting the "no professional relationship" statement is a fact. The minutes' omission of Le's ownership and Lindholm's reason is a fact. The pattern of real estate money is a fact. The inference — that these facts add up to a conflict culture rather than a crime — is ours, and we label it.

---

## 6. The systemic frame

Lakewood's council is part-time. Members are paid roughly $300–$470 per meeting and are expected to hold outside jobs. The city has a Code of Ethics (LMC 1.32) and council rules that allow abstention "for stated conflict of interest or appearance of fairness." It has no independent ethics board. The city attorney and city manager report to the council; neither can independently police the council's conflicts. The state has no agency that enforces RCW 42.23 against city council members. The peer comparison in this case found Lakewood's dual-government employment rate (5 of 7, 71%) is a clear outlier against a 0–29% peer range (median 14%), while the absence of an ethics board is typical: 4 of 5 peer cities lack one.

The Lindholm case shows how the system works in practice. The member self-declares what he thinks is relevant. The minutes summarize. The video captures the rest. The F-1 discloses the financial interests, but only to someone who knows to look. The public is left to assemble the picture. The story is not that one councilmember is uniquely conflicted. The story is that the design relies on the member's own characterization of his conflict, and the record does not require him to be complete.

---

## 7. Right of reply

Draft letter with 12 numbered questions: `right-of-reply.md`. Not sent. The letter asks Lindholm to confirm or correct:
1. The ownership and rental status of 8814-8815 Lochburn, 107-109 Lake Louise, and 9908 Meadow.
2. Whether he disclosed the rental ownership to the city attorney or council before the May 4 vote.
3. Whether he sought an ethics opinion on Ordinance 849.
4. The date and amount of the Terry Wise & Associates payments listed on his 2025 F-1.
5. Whether he told the council about those payments before saying "I do not have a professional relationship with Mr. Wise."
6. The date and terms of the sale of 705 S 9th St Suite 102 to Terry Wise.
7. The nature of his current relationship with Wise.
8. Whether he discussed the Solberg contract with Wise or Le outside the public meeting.
9. Whether he owns any other rental property in Lakewood not listed on the F-1.
10. Whether the "Community for Philip Lindholm" operating name on Wyoming Housing Holding Company is a filing error.
11. Whether Concord Counsel is a trade name of Washington Ventures Management or a separate business.
12. Whether he agrees the minutes should have recorded Le's ownership and his reason for abstaining.

---

## 8. Story outline and draft lede

**Headline options:**
- "The Landlord on the Council"
- "Lakewood's Rental Rules and the Councilmember Who Owns 18 Units"
- "A Friendship, a Contract, and a $12,000 Disclosure"

**Draft lede:**
> On May 4, the Lakewood City Council rewrote the rules for rental housing. One of the members, Philip Lindholm, owns an 18-unit apartment complex through an LLC a few miles from City Hall. No disclosure of that ownership appears in the public minutes or video; he is not recorded in opposition.
>
> A month earlier, the same councilmember, Philip Lindholm, abstained on a $71,181.85 city abatement contract involving a property owned by a local real estate investor and represented by his friend and former colleague, Terry Wise. Lindholm told the council he had no professional relationship with Wise. His financial disclosure, filed two weeks earlier, lists Wise's firm in the business-customer section, which reports payments of $12,000 or more, for consulting.

**Nut graf:**
> The case is a window into how Washington's part-time city councils manage the conflicts built into the job. Lakewood has an ethics code. It does not have an ethics board. The official minutes record the votes but not the reasons; the video records the reasons but not the financial disclosures; the disclosures are filed with the state but rarely read. The public has to assemble the picture from four different records.

**Sections:**
1. The portfolio (F-1 + assessor + rental listings).
2. The vote (Ordinance 849; the self-certification and ADU provisions; his statements).
3. The abstention (Solberg; Le; Wise; the $71K contract).
4. The $12,000 (F-1; PDC instructions; his statement).
5. The minutes (what the official record omits).
6. The system (no ethics board; peer comparison; the part-time council paradox).
7. What he says (right of reply).

**Kicker:**
> Lakewood's ethics code says councilmembers should refer conflict questions to the code. The code has been on the books since at least 2019. In 16 years of minutes, the city has recorded one recusal. The question is not whether the rules exist. It is whether anyone is expected to use them.

---

## 9. Next records to pull

1. **PDC F-1 PDF / statement detail** — exact date and amount of the Terry Wise & Associates business payment; whether the 2025 form carried it forward from 2024.
2. **Pierce County recorded deed** — 705 S 9th St Suite 102, Tacoma; sale date and price to Terry Wise.
3. **City of Lakewood PRA** — the Solberg abatement file: owner correspondence, Wise's engagement, any communications with Lindholm, and any conflict memo.
4. **City of Lakewood PRA** — Lindholm's rental registration records for 8814-8815 Lochburn and 107-109 Lake Louise; inspection status.
5. **City of Lakewood PRA** — any written ethics advice or conflict disclosure from Lindholm to the city attorney.
6. **2026 F-1** (due April 2027) — whether the Wise consulting relationship continued.
7. **Campaign C3/C4** — the $200 in-kind entry and the fair-market value of the podcast production.
8. **Pierce County Assessor** — full parcel detail and sales history for 8814-8815 Lochburn and 107-109 Lake Louise (unit count, assessed value, sale history).

---

## 10. Evidence log

New items E047–E061 are recorded in `evidence-log.md`. Existing case items E001–E046 remain in the main case file. Custody: transcript excerpts were captured from the city's YouTube videos on 2026-11-12; the F-1 JSON was captured from data.wa.gov on 2026-11-12; SHA-256 hashes are in the evidence log.
