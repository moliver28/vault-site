# Red-Team Audit — Lindholm Deep Dive

**Question:** Assume every finding is wrong. What can be disproved, what is merely unverified, and what survives?
**Date:** 2026-11-12
**Method:** Re-read the primary records and attacked the ownership chain, vote attribution, donor classification, F-1 field semantics, and the minutes/video comparison. No new interviews. Every downgrade is recorded here and in `verification-matrix.md`.

---

## Bottom line

The core survives in narrowed form. Three claims collapse, six weaken, and the rest hold. The story is still publishable, but not in the version first written. The defensible version is:

> A Lakewood councilmember who owns an 18-unit apartment complex through an LLC did not disclose it in the public record before voting on the city's rental-housing rules. A month earlier, he told the council he had no professional relationship with a land-use consultant whose firm appears on his own financial disclosure as a business customer — after abstaining on a contract involving the consultant's client.

That is narrower than "the landlord voted for the rental rules while being paid by the consultant." It does not claim a crime, a quid pro quo, or a specific final-vote aye that the record does not individualize.

---

## COLLAPSED

### C1. "At least $10,200 of Lindholm's campaign came from real estate, development, and landlord interests."

**Why it collapses:** Two of the largest components are not verified as real estate money.
- **Stonegate Associates LLC ($2,000):** The name matches a New Jersey security-consulting firm. The Lakewood apartment complex called Stonegate Apartments is managed by Dobler Management Company, not by a "Stonegate Associates LLC." The campaign-finance report itself labeled the donor "Real estate/property management?" with a question mark. There is no evidence the donor is a real estate entity.
- **Capital Ventures ($2,400) and McKinley Sands ($2,400):** Sands McKinley is a family-law attorney, founder of McKinley Irvin. "Capital Ventures" appears in his LinkedIn as a venture, but no source establishes it as a real estate developer. The employer field says "Capital Ventures / owner," not "developer."
- The verified real estate/landlord/construction floor is **$6,300**: Terry Wise $2,400 + Landlord Solutions $1,200 + Master Builders Association of Pierce County $1,200 + Washington Association of Realtors PAC $500 + Rémy Claude $1,000 (self-described "Developer"). Add $200 in-kind from Terry Wise & Associates.
- **Verdict:** Replace "$10,200+" with "at least $6,300 from verified real estate, landlord, and construction interests; two additional donors whose business classification is unverified." Do not call Stonegate or Capital Ventures real estate money without entity records.

### C2. "Lindholm voted for Ordinance 849."

**Why it collapses:** The final vote was a voice vote. The May 4 transcript records: "All those in favor of ordinance number 849 as amended, please signify by saying I. >> I. >> All those opposed. >> The eyes have it. So uh ordinance number 849 as amended is uh is adopted." Only Councilmember Brandstetter is recorded saying he would vote nay. The minutes say "carried with Councilmember Brandstetter voting in opposition." Neither record individualizes the ayes. Lindholm could have abstained silently; a voice vote does not capture that.
- **What survives:** Lindholm is **not recorded in opposition**. He voted to **keep the self-certification provision**: the motion to strike 5.60.080(C) failed with "Councilmember Lindholm, Pearson, Deputy Mayor Belle and Mayor Bocchi voting in opposition" (minutes, May 4). That is an individual, recorded vote in favor of the landlord-friendly provision.
- **Verdict:** Replace "voted for Ordinance 849" with "the ordinance carried; Lindholm is not recorded in opposition; he voted to keep the self-certification provision." Do not say he cast a final aye unless the video audio confirms it.

### C3. "The F-1 shows zero business income."

**Why it collapses:** Already corrected in the case file. The 2025 F-1 discloses three real estate entities (Wyoming Housing Holding Company 100%, Washington Ventures Management 100%, 8814-8815 Lochburn LLC 84%), seven properties, and a business-customer payment from Terry Wise & Associates. The narrow issue is that **Concord Counsel is not named** as a business association. The old "zero business income" framing is misleading and must not publish.

---

## WEAKENED

### W1. "An 18-unit apartment building."

**Status:** Ownership is verified (F-1 84% + assessor taxpayer). The **unit count** comes from a Redfin listing ("18-unit apartment building... two buildings: an 8-unit and 10-unit"), not from an assessor unit count pulled in this pass. The assessor record was not opened to a unit-count field. **Downgrade to corroborated.** The story should say "listed as an 18-unit complex" or "an apartment complex the listing describes as 18 units."

### W2. "He is a landlord."

**Status:** He owns rental property through LLCs. "Landlord" implies day-to-day operation; the F-1 says "Real Estate Activities," not "landlord." The Lochburn complex is a rental apartment building; the ownership is his through the LLC. **Narrow to "owns rental property through LLCs"** in the body. The headline "The Landlord on the Council" is editorial framing and can stand only if the body supplies the precise facts.

### W3. "Without disclosing his rental portfolio."

**Status:** No disclosure appears in the May 4 minutes or video. A written disclosure, ethics memo, or executive-session statement could exist outside those records. **Narrow to "no disclosure appears in the public minutes or video."** Do not say "he concealed it."

### W4. "The minutes omit Le's ownership disclosure."

**Status:** The minutes' summary of her **oral** comment omits it. The video contains it. The minutes also say "The City Council received written comments in advance of the meeting from Michelle Le" — she may have disclosed ownership in writing. **Narrow to "the minutes' oral-comment summary omits her ownership statement; the video contains it."** Do not say the city record as a whole omits it.

### W5. "The F-1 lists Wise's firm as a $12,000+ business customer."

**Status:** The PDC instruction page describes the section as "Payments Received From Business Customers (>$12,000)," and the F-1 JSON lists Terry Wise & Associates under `business_payments` for "Consulting." The mapping is strong but is an interpretation of the JSON schema; the exact amount and date are not in the public JSON. **Downgrade to corroborated, not verified.** The story should say "the form's business-customer section, which reports payments of $12,000 or more, lists..." and note that the exact date/amount requires the imaged form.

### W6. "The duplex at 107-109 Lake Louise is a rental."

**Status:** The F-1 lists 107-109 Lake Louise as his real estate; the assessor taxpayer is a trust/LLC. An apartments.com listing advertises "103-109 Lake Louise Dr SW" as a rental. The listing covers a range that includes his address, but it does not prove his specific unit is rented. **Keep the Lochburn building as the landlord evidence; qualify the duplex as "a property the F-1 lists and the building is advertised as a rental; the specific unit's status is not independently verified."**

---

## SURVIVES

1. **Ownership disclosures.** The 2025 F-1 reports 84% of 8814-8815 Lochburn Lane SW Lakewood, LLC; 100% of Wyoming Housing Holding Company; 100% of Washington Ventures Management. Verified (F-1 statement 132557).
2. **The Lochburn LLC is the assessor's taxpayer** for 8814-8815 Lochburn Ln SW (parcel 0220353064). Verified (ATIP).
3. **Ordinance 849 added a self-certification option** at 5.60.080(C) and an **ADU exemption** at 5.60.025(A)(7)/I. Verified (ordinance text in May 4 packet).
4. **Lindholm voted to keep the self-certification provision.** The motion to strike it failed with Lindholm, Pearson, Belle, and Bocchi in opposition. Verified (May 4 minutes).
5. **Lindholm said "I've been a licensed real estate professional for 16 years now"** and described "personal experience with the rental safety program... it doesn't always make the property safer but it always raises the cost every single time." Verified (May 4 video transcript).
6. **Lindholm abstained on Motion 2026-25**, the $71,181.85 Solberg abatement contract. Verified (April 6 minutes + video).
7. **Lindholm said "I do not have a professional relationship with Mr. Wise, but I do have a long-standing friendship and former colleague of mine."** Verified (April 6 video transcript).
8. **The 2025 F-1 lists Terry Wise & Associates under Washington Ventures Management's business payments for "Consulting."** Corroborated (F-1 JSON + PDC instructions); exact date/amount unverified.
9. **Terry Wise said he was representing a client that owns 5105 Solberg.** Verified (April 6 video transcript).
10. **Michelle Le said "I'm the owner of the property at 5105 Solberg Drive Southwest in Lakewood."** The assessor lists Tran Sinh V & Le Michelle T. Verified.
11. **The minutes' oral-comment summary omits Le's ownership statement.** Verified (minutes vs. video).
12. **Lindholm received $2,400 from Terry Wise and $200 in-kind from Terry Wise & Associates.** Verified (PDC contributions).
13. **The 2024 F-1 lists the same Wise business payment.** Verified (statement 122447).

---

## What would still kill the surviving story

- A written conflict disclosure or city attorney memo showing Lindholm disclosed his rental ownership before May 4.
- Evidence that the Wise consulting payment was 2024 only and the relationship had ended before April 6, 2026.
- Evidence that the Lochburn LLC's units are not residential rentals (owner-occupied, vacant, or non-residential).
- A recorded abstention on the final Ordinance 849 vote that the voice vote did not capture.
- Evidence that 107-109 Lake Louise is not his or not rented.

None of these has been found. The surviving story is narrower but survives them all except the first and third, which are the two records to pull next.

---

## What changed in the record

- `report.md`: corrected the final-vote claim, the donor floor, the "landlord" phrasing, the "without disclosing" phrasing, the 18-unit count, the F-1 payment grade, and the duplex rental qualification.
- `verification-matrix.md`: LDD-02 downgraded to corroborated; LDD-04 rewritten; LDD-07 narrowed; LDD-11 downgraded to corroborated; LDD-17 rewritten to the $6,300 floor; LDD-03 narrowed.
- Main case file: Subjects line and Session Log corrected.
