---
project: Investigations
type: note
title: "Philip Michael Lindholm — Person-Level Profile"
case: 2608-lakewood-council
subject: Philip Michael Lindholm
role: Lakewood City Council, Position 3
status: WORKING DRAFT — NOT FOR PUBLICATION
created: 2026-11-13
last_updated: 2026-11-13
classification: Internal investigative dossier. Contains self-reported claims, unverified leads, and pre-publication material. Do not publish or sync to the public monorepo.
---
# Philip Michael Lindholm — Person-Level Profile

> **Working draft. Not for publication.** This is a person-level dossier, not a story. Every assertion is graded. Only **V** (verified) and **C** (corroborated) assertions may enter copy. **S** (self-reported/single-source), **I** (inference), and **U** (unverified/open) items are reporting leads, not facts. The subject has not been sent the expanded right-of-reply letter; publication is blocked until that happens and the reply window closes.

## 0. Source key and grade definitions

| Tag | Meaning | Publication rule |
|---|---|---|
| **V** | Verified: two independent primary anchors, or a primary document plus a corroborating person/record | May publish |
| **C** | Corroborated: one primary source matched by an independent secondary source | May publish with attribution |
| **S** | Self-reported or single-source: the subject's own bio, campaign filing, social media, or one outlet | Attribute; do not present as independently established |
| **I** | Inference: a logical reading of verified facts, explicitly labeled | May publish only as a labeled inference, never as fact |
| **U** | Unverified/open: a lead, a claim not yet checked, or a negative that cannot be proven | Do not publish as fact; report as open |

**Source IDs** refer to the case evidence log (`evidence-log.md`, E047–E061) and the new profile evidence series (E062–E078) listed in §13. Where a claim is new and not yet in the log, the source URL is given inline.

---

## 1. Snapshot

- **Philip Michael Lindholm**, born December 10 (year not public), Seattle, Washington. [V for name/birth date: Wikipedia/DBpedia; official bio. Year is not public.]
- **Lakewood City Council, Position 3.** Elected November 2025; took office January 2026; term expires December 31, 2029. The council is part-time and nonpartisan; the mayor is chosen by the council. [V: city council page; Pierce County voters pamphlet.]
- **Oxford-trained scholar.** DPhil from Oxford (2010) after three master's degrees (Judaism, Christianity, Islam); master's from Middlesex; two bachelor's degrees from Central Washington; AA from Green River; additional study at L'École Normale Supérieure (Paris, 2005) and Juilliard (2007); Rhodes Scholar finalist. [C: official bio, Wikipedia, Amazon author bio; no university registrar record pulled. The DPhil thesis title is not verified.]
- **Law student, not (yet) an attorney.** The official 2025 voters pamphlet lists **“Seattle University School of Law (JD in progress)”** and **“University of Washington Tacoma (BA in progress).”** His X bio says “Law Student.” The Puyallup Tribal Court lists him as an **Advocate**, not an Attorney. [V for the pamphlet text and the court listing; S for the pamphlet's self-reported education; no registrar confirmation.]
- **Media maker.** Former BBC/ITV documentary producer and presenter; author of *Latter-day Dissent* (2011) and *Voyeur: Notes of Disquiet* (2011); singer-songwriter behind Whiskey N' Rye (formed 2013); TEDx speaker (2019); host of *The Informed Citizen* podcast, whose YouTube channel reports **117K subscribers, 377 videos, 1.5M views** (joined 2011). [C/V: official bio, Wikipedia, AllMusic, YouTube page.]
- **Air Force chaplain.** Captain and chaplain, U.S. Air Force / Washington Air National Guard, 194th Wing, Camp Murray; began as Wing Chaplain in January 2017; hospital chaplain at CHI Franciscan/MultiCare; board-certified chaplain (NAVAC 2019; APC per author bio); Mary Bridge grief-group facilitator for eight years. [V for the 194th Wing chaplain role: DVIDS, Jan. 29, 2017; C for rank/certifications: official bio, Amazon bio.]
- **Real estate broker and landlord.** Licensed Washington real estate broker since 2011; former CEO of **Terry Wise & Associates**; HomeLight's agent profile lists him at Terry Wise & Associates (16 years, 50 transactions, $354K average, 44 single-family homes, 3.7/5 on three reviews). His 2025 F-1 reports **84% of 8814-8815 Lochburn Lane SW Lakewood LLC**, 100% of **Wyoming Housing Holding Company**, and 100% of **Washington Ventures Management**, plus seven properties. [C: LinkedIn/HomeLight/official bio; V: F-1.]
- **Mediator and tribal-court advocate.** Founder/CEO of **Concord Counsel** (mediation, tribal law, community relations); listed on the Puyallup Tribal Court Courtesy Bar List as **Advocate, Bar No. 585** (Jan. 6, 2026); claims admission in Puyallup, Swinomish, and Makah tribal courts. [V for Puyallup; S/U for Swinomish and Makah.]
- **Local media co-founder.** Co-founder of **The Cascadian**, a 501(c)(3) community news outlet in Lakewood, with former councilmember Walter Neary; the outlet's mailing address is the same PO Box as Lindholm's campaign; it publishes his columns. [V: The Cascadian About page; The Seattle Times; ProPublica IRS record.]
- **Live civil litigation.** Defendant in **Jacob Lawrence v. Philip Lindholm**, Pierce County Superior Court No. **26-2-08192-7**, docketed as a **Consumer Protection Act** case, filed April 29, 2026; 62-page complaint; jury demand; trial set April 28, 2027. The complaint has not been obtained; no allegation is characterized here. [V for the docket; U for the allegations.]
- **Clean criminal/tax index (as searched).** The Pierce County LINX public index returned no Superior Court criminal cases, no District Court criminal cases, no tax warrant/judgment cases, and no District Court civil cases for “Lindholm, Philip” between 2010 and 2026. The index expressly disclaims accuracy and cannot associate names to individuals without case research; this is a search result, not a clearance. [V for the search result; caveat required.]
- **The core tension.** The public persona is scholar, chaplain, mediator, and public servant. The private footprint is broker, landlord, media producer, and founder of a local news outlet. The investigative question is not whether those roles are legal — most are ordinary — but whether the disclosure and recusal regime makes the intersections visible to the public. The strongest documented intersection is the **Terry Wise cluster**: former employer, campaign donor, podcast production partner, and the consultant for the Solberg property whose abatement contract Lindholm abstained on.

---

## 2. Identity and biography

### 2.1 Core identity

| Field | Value | Grade / source |
|---|---|---|
| Full name | Philip Michael Lindholm | V: Wikipedia/DBpedia; official bio |
| Born | December 10; year not public; Seattle, WA | V (date/place); U (year) |
| Current office | Lakewood City Council, Position 3; took office 2026; term to 12/31/2029 | V: city page |
| Party | Nonpartisan office | V: city page |
| Campaign committee | Community for Philip Lindholm, PO Box 39192, Lakewood, WA 98496 | V: campaign site; PDC |
| Official contact | PLindholm@cityoflakewood.us; City Hall (253) 983-7705; cell (253) 401-6825 | V: city page |
| Campaign contact | mail@votephilip.com; (253) 234-4686; votephilip.com | V: voters pamphlet |
| Family roles (public) | Son; father of a son (he refers to “my son” in the kickoff speech); no spouse information public | S: kickoff transcript; voters pamphlet (“son, father”) |
| Public mailing address | PO Box 39192, Lakewood, WA 98496 | V: campaign, Chamber, Cascadian, tribal bar list |
| Tribal bar listing | 5409 100th St SW, Box 39192, Lakewood, WA 98499; 206-659-5960; Advocate Bar No. 585 | V: Puyallup Tribal Court list, 1/6/2026 |

**Identity match — what the record shows.** The councilmember and the Oxford-educated Kierkegaard scholar/chaplain are the same person on the documentary record, but the photographic comparison is not clean. The chain is:

- The official campaign site `philiplindholm.com` is the same domain as the academic's pre-campaign personal site. The 2013 captures describe "Dr. Lindholm" as a musician, author, and entrepreneur with three master's degrees and an Oxford doctorate, and list him as "principal consultant and broker with The Lindholm Group… associate of Terry Wise & Associates." A later "Consulting" page on the same site says he was "CEO at Terry Wise & Associates." The council bio says he became "CEO of a real estate brokerage and consulting firm"; HomeLight lists him at Terry Wise & Associates. [V: Wayback captures, 2013 and 2025; E079.]
- The DVIDS article (2017) names "Rev. Dr. Philip Lindholm" as the incoming 194th Wing chaplain and gives his early life — Seattle, Decatur High School in Federal Way, Green River Running Start, Central Washington, Oxford, three master's degrees, CHI Franciscan chaplaincy — plus his wife **Lori** and son **Declan**. The city bio, voters pamphlet, Chamber bio, and campaign site repeat the same early life and military/chaplain history. [V: DVIDS; E064.]
- The Wikipedia page (Q7183978) is the academic's biography: same Green River/Central Washington/Oxford/Juilliard/BBC/ITV/Whiskey N' Rye history. Its 2019 photo is captioned "Dr. Philip Lindholm addressing an audience of Air Force members at Camp Murray." The page does **not** mention Lakewood or the council, which is the main reason to pause. [V: Wikipedia; E080.]
- The Puyallup Tribal Court list uses the same PO Box as the campaign (39192, Lakewood) and lists him as an Advocate, Bar No. 585. [V: E063.]
- Family-name corroboration: a **Lori Lindholm, LICSW** practices in Lakewood (NPI 1336872043); a **Declan Lindholm** maintains a public racing blog/Instagram; the councilmember's Facebook page includes a post from Makah tribal court referring to "my son and his father," and a post referring to "my wife." The 2017 DVIDS article names the chaplain's wife Lori and son Declan. This is consistent with one household, though it is not a single document that names all three together. [C: public profiles/posts; E081/E083.]
- **The photo caveat.** The 2017 DVIDS and 2019 Wikipedia photos show a leaner man with darker hair and a longer, narrower face; the 2025/2026 council and Facebook photos show a fuller face with lighter hair. The difference could be nine years of aging, weight, lighting, and professional retouching — or it could be two different men. I cannot resolve it by eye. A facial-recognition comparison or a direct family/vital record would settle it. Until then, the identity match rests on the documentary convergence, not on the photographs. [V documentary; U photographic.]

**Bottom line:** the documentary record is strong — same domain, same Oxford/film/music biography, same Terry Wise & Associates history, same 194th Wing chaplaincy, same wife/son names, same PO Box. The main weak link is the visual comparison; a second open question is the F-1's military pension timeline, which is hard to square with a 2016 accession unless there was prior service or household income. If a specific record shows a different Philip Lindholm (a birth year, a marriage record, a second DVIDS profile), the match should be re-opened. [V/C; photo U.]

**The theology-to-real-estate question.** The transition looks implausible if you assume a linear academic career. The record shows a portfolio career instead. The 2013 capture of `philiplindholm.com/about` — the subject's own pre-campaign site — lists the Oxford doctorate, three master's degrees, BBC/ITV film work, Whiskey N' Rye, and **“principal consultant and broker with The Lindholm Group… associate of Terry Wise & Associates”** on the same page. It also lists Stage 1 Studio & Rehearsal, University Place Press, Oxford Tutoring Services, and 24/30 Cinema. The real estate work was one strand of an entrepreneurial career, not a replacement for the academic work. The 2011 license, the 2013 site, the 2025 consulting page (“CEO at Terry Wise & Associates”), HomeLight, and the F-1 all show a long-standing real estate/business practice; the 2016 chaplaincy and 2025 council campaign came later. This does not resolve the identity question, but it removes the “impossible career arc” objection. [V: E079; I: interpretation.]

### 2.2 Early life and education

- **Seattle native; left high school at 17.** He began at Green River Community College at 17, earned an AA, then went to Central Washington University, where he is described as graduating with high honors and two bachelor's degrees. [S: official bio, Wikipedia, Amazon. No transcript.]
- **Rhodes Scholar finalist.** Repeated in the official bio, voters pamphlet, Amazon bio, and Wikipedia. [S: no Rhodes Trust confirmation pulled. Flag for verification before publication.]
- **Oxford.** Doctorate and two master's degrees at Oxford; the doctorate is described as a DPhil in philosophical theology (2010), with separate master's degrees in Judaism, Christianity, and Islam; doctoral advisor George Pattison. [C: official bio + Wikipedia + Amazon. The Oxford thesis title is not verified in ORA by this search; flag.]
- **Other study.** Master's from Middlesex University; study at L'École Normale Supérieure in Paris (2005); Juilliard (2007); currently listed as **JD in progress at Seattle University School of Law** and **BA in progress at University of Washington Tacoma** in the 2025 voters pamphlet. [S: official bio/Wikipedia for Paris/Juilliard; V for the pamphlet text, but the pamphlet is candidate-supplied and the county does not verify it.]
- **The education portfolio is unusual and relevant to the profile:** a doctorate and three master's degrees, two bachelor's degrees, a law degree in progress, and a second BA in progress — all while serving on the council, running a mediation practice, and owning rental property. This is not a scandal; it is a workload and role-density fact that bears on capacity and on the “polymath” public identity. [I: inference from the schedule; label as analysis.]

### 2.3 Academic and literary career

- **Kierkegaard and philosophy of religion.** Described as a Kierkegaard scholar and former lecturer in comparative religion at the University of Washington and Oxford. [C: Wikipedia + official bio.]
- **Books.** *Latter-day Dissent: At the Crossroads of Intellectual Inquiry and Ecclesiastical Authority* (Blackwell, 2011), edited with an introduction; a collection of interviews with LDS intellectuals who faced ecclesiastical discipline, including the “September Six.” [V: Wikipedia/Book review/Dialogue Journal; LinkedIn publication list.] *Voyeur: Notes of Disquiet* (Kofford Books, 2011). [C: LinkedIn + Wikipedia.]
- **Chapters/articles.** “The Struggle Within,” in *Metallica and Philosophy* (Open Court, 2007); “Stu Ungar & Emmanuel Levinas” (2006); a review in *Levinas & Biblical Studies*. [S: LinkedIn publication list.]
- **Teaching.** Lecturer at Oxford and the University of Washington. [C: official bio + Wikipedia.]
- **Public intellectual.** TEDx talk *“The Secret to a Meaningful Life”* (2019), framed around death, gratitude, and three hospital patients. [V: YouTube; transcript.]
- **Assessment.** The academic record is real and substantial, but the profile should not repeat “Rhodes Scholar finalist” or the exact Oxford thesis without checking the Rhodes Trust and ORA. The books and the TEDx talk are independently visible. [I: verification strategy.]

### 2.4 Film, television, and music

- **BBC/ITV.** Official bio: produced documentaries with the BBC and ITV. Wikipedia credits include BBC's *Who Murdered Warren Taylor?* (2005), ITV's *The Grail Trail* (presenter), *The Muslim Jesus*, BBC's *History of Christianity*, and *The Funny Thing About Ramadan*. [C: official bio + Wikipedia/IMDb.]
- **Film.** *Pieces*; *All Sun and Little White Flowers*; work with Albert Maysles is claimed in the official bio. [S: official bio/Wikipedia; not independently verified.]
- **Music.** Whiskey N' Rye, a Seattle roots/Americana band formed in 2013 by Lindholm; self-titled album (2014); described by AllMusic as “centered on the music of singer/songwriter, filmmaker, writer, and academic Philip Lindholm.” [C: AllMusic + Wikipedia + Discogs.]
- **Why it matters.** The film/music career is part of the public persona and explains the podcast's production values and media network. It is not a conflict by itself. [I: analysis.]

### 2.5 Military and chaplaincy

- **Air Force Captain; Washington Air National Guard chaplain.** DVIDS, Jan. 29, 2017: “Rev. Dr. Philip Lindholm, who will soon begin training to serve as the Wing Chaplain,” 194th Wing, Camp Murray, Washington. The photo caption shows him at a chapel service in the Wing Auditorium. [V: DVIDS.]
- **Rank.** Official bio and voters pamphlet: “Air Force Captain”; Amazon author bio: “Captain Chaplain for the Washington Air National Guard.” [C: official bio + Amazon; the DVIDS article does not state rank in the visible text.]
- **Chaplaincy credentials.** Board-certified by the National Association of Veterans Affairs Chaplains (2019) and the Association of Professional Chaplains (per Amazon bio); ordained by the WCICC (per Amazon bio); chaplain at CHI Franciscan/MultiCare before the Guard. [C: LinkedIn certification + Amazon bio; the APC/WCICC details are self-reported.]
- **Grief work.** Eight years as a grief-group facilitator at Mary Bridge Hospital. [S: official bio, voters pamphlet, Chamber bio; repeated consistently.]
- **Financial footprint.** The 2025 F-1 reports OPM military pension ($30K–$59K), DFAS military pension ($60K–$99K), and VA benefits ($60K–$99K), plus a UW Medical Center “medical assistant” line ($0–$29,999). [V: F-1. The “medical assistant” label is the form's; the role is not explained.]
- **Assessment.** The military/chaplain identity is well documented and central to his public appeal. It also explains the grief/vulnerability framing in his campaign and TEDx talk. [I: analysis.]

### 2.6 Civic and community roles

- Lakewood Planning Commission (pre-council). [S: official bio/voters pamphlet; appointment date not verified.]
- Lakewood Rotary; Steilacoom Kiwanis. [S: official bio/Chamber.]
- Mary Bridge Hospital grief-group facilitator (8 years). [S: official bio.]
- Pierce County Dispute Resolution Center mediator; certified mediator (2026). [C: LinkedIn certification + official bio.]
- Continuum of Care Board; Point-in-Time Homelessness Count. [S: voters pamphlet.]
- Lakewood Playhouse Board. [S: his Cascadian column, “A Story Worth Telling.”]
- The Cascadian co-founder. [V: About page + Seattle Times.]
- Informed Citizen Podcast; TEDx speaker. [V/C: YouTube/TEDx.]

### 2.7 Public persona vs. private footprint — analysis, labeled

The public biography is a coherent “servant-leader” narrative: a Seattle kid who left high school early, won a Rhodes finalist slot, studied at Oxford, made documentaries, served as a chaplain, buried patients, comforted grieving families, and came home to serve. It is authentic in its broad outlines and unusually well documented for a local councilmember.

The private footprint is more layered: a licensed broker who was CEO of a brokerage; a landlord with an 84% stake in an apartment complex listed as 18 units; a mediator whose practice includes tribal-court real estate and family law; a media producer with a 117K-subscriber podcast; and a co-founder of a local news outlet. None of these is inherently improper. The investigative question is **role density and disclosure**: when the same person is the broker, the landlord, the mediator, the media owner, and the councilmember, the public cannot easily see which hat is on at any given vote. [I: analytical frame; not a finding of wrongdoing.]

---

## 3. Public office and governance record

### 3.1 Planning Commission

- He served on the Lakewood Planning Commission before the council. The official bio and voters pamphlet list it; a Facebook profile snippet says “Lakewood Planning Commissioner Jan 2024 – Present.” [S: official bio; U: exact appointment date and attendance record.]
- The case file reviewed 2026 council minutes, not the full Planning Commission record. A complete attendance/vote record is a records request item. [U]
- **Why it matters.** Planning Commission service is the usual pipeline to council in Lakewood (Talbo, Pearson, Herr also served). It is a legitimation credential, not a conflict. [I]

### 3.2 City Council election and term

- **Position 3**, the seat held by Mayor Jason Whalen, who did not seek re-election. He ran against Jennifer Lamari and (briefly) Taylor Whitt in the 2025 primary; the News Tribune described him as the establishment-backed candidate and Lamari as the Indivisible Tacoma-backed candidate. [V: News Tribune, July 18, 2025; voters pamphlet.]
- **Endorsements:** Mayor Jason Whalen; former mayors Don Anderson and Doug Richardson; Deputy Mayor Mary Moss; Councilmembers Paul Bocchi and Ryan Pearson; former Sheriff Paul Pastor; former Police Chief Mike Zaro; School Board President Alyssa Anderson Pearson; past and present Rotary presidents; local business owners. [V: voters pamphlet; News Tribune.]
- **Result:** won the November 2025 general election. The case file records **59.4%**; verify against the Pierce County canvass before publication. [C: case file; U: exact canvass.]
- **Term:** took office January 2026; expires December 31, 2029. The council is part-time (the city describes members as part-time, nonpartisan). [V: city page.]

### 3.3 Key votes and recusals

**A. Ordinance 849 — rental-housing licensing/inspection rewrite (May 4, 2026).**

- The ordinance amended LMC Chapter 5.60, adding a **self-certification option** (5.60.080(C)) and an **ADU exemption** (5.60.025(A)(7)/I). [V: ordinance text; E051.]
- The final vote was a **voice vote**; Lindholm is not recorded in opposition. The record does not individualize the ayes. [V: minutes; E052.]
- He **seconded the ADU amendment** and voted **against deleting the self-certification provision**; the motion to strike failed with Lindholm, Pearson, Belle, and Bocchi opposed. [V: minutes; E052.]
- He said: **“I've been a licensed real estate professional for 16 years now”** and described **“personal experience with the rental safety program… it doesn't always make the property safer but it always raises the cost every single time.”** [V: video transcript, May 4, 2026; E053.]
- **No disclosure of his rental ownership or a recusal appears in the May 4 minutes or video.** This is an absence finding, not proof of concealment; a written disclosure or ethics memo outside the public record could exist. [V absence; E052/E053. Grade: verified absence, with caveat.]

**B. Motion 2026-25 — 5105 Solberg Dr SW abatement contract (April 6, 2026).**

- The contract was a **$71,181.85** abatement award to DP Excavation for 5105 Solberg Dr SW. The staff report documents 2015–2024 illegal residential use, 12 people living there in June 2024, a July 23, 2024 Findings and Order, June 6 and November 6, 2025 warrants, nine households relocated, $30,019 advanced and repaid, a repair estimate of $349,677.60 vs. demolition at $135,423, and an assessed value of $806,600. [V: staff report; E058.]
- Lindholm pulled the motion from consent and **abstained**; the contract passed **6–0**. [V: minutes/video; E054/E055.]
- He said: **“I need to disclose that I do not have a professional relationship with Mr. Wise, but I do have a long-standing friendship and former colleague of mine.”** He also said, **“I would expect to abstain from any vote on this.”** [V: video transcript, April 6, 2026; E055.]
- **Terry Wise** told the council he was “a land use consultant” representing “a client that owns property at 5105 Solberg Drive Southwest.” **Michelle Le** told the council, **“I'm the owner of the property at 5105 Solberg Drive Southwest in Lakewood.”** [V: video transcript; E056.]
- The **official minutes** describe Le as a “Lakewood resident” speaking about “her experience in residential real estate” and **omit her ownership statement**. [V: minutes vs. video; E054/E056.]
- **Why it matters.** This is the cleanest documented intersection: Lindholm abstained on a contract benefiting a property owned by Le and represented by Wise, his former colleague and campaign donor. The abstention is the right procedural move; the open questions are the scope of the “no professional relationship” statement and whether the F-1's Wise consulting payment is consistent with it. [I: analytical frame; not a finding of quid pro quo.]

**C. Other votes.** The case file records votes against the sales-tax increase (with Lauricella and Brandstetter) and against the cannabis-sales ordinance (with Bocchi, Brandstetter, Pearson). These are useful for an ideological profile but are not re-verified in this session. [C: case file; verify minutes before publication.]

### 3.4 Committee assignments and outside boards

- The city's online bio lists **no council liaison or board assignments** for Lindholm, unlike several colleagues whose bios name Pierce Transit, South Sound 911, the Arts Commission, etc. This may be an omission on the webpage rather than an absence of assignments. [U: check the city's committee roster.]
- Outside roles that intersect with city policy: Lakewood Rotary, Steilacoom Kiwanis, Continuum of Care Board, Pierce County DRC, Lakewood Playhouse Board, The Cascadian. [S/V as above.]
- **Assessment.** The absence of listed assignments is not a finding; it is an open records item. [I]

### 3.5 Official bio claims vs. independent record

| Official claim | Independent check | Grade |
|---|---|---|
| Rhodes Scholar finalist | No Rhodes Trust record pulled | S — verify |
| Oxford doctorate, three master's | Official bio + Wikipedia + Amazon agree; no ORA thesis record found | C — verify thesis |
| Air Force Captain | DVIDS confirms 194th Wing chaplain; rank from bio/Amazon | C |
| BBC/ITV documentaries | Wikipedia/IMDb credits | C |
| Real estate broker since 2011 | LinkedIn certification; HomeLight 16 years | C |
| CEO of a real estate brokerage | HomeLight lists Terry Wise & Associates; F-1/podcast credits | C |
| Member of Puyallup Tribal bar | Puyallup Court list: Advocate Bar No. 585 | V |
| Barred in Swinomish and Makah | No public roster entry located; tribal codes allow non-attorney advocates | U |
| Seattle U JD in progress | Voters pamphlet says so; X bio “Law Student”; no registrar record | S — verify |
| Tacoma Prosecutor's Office; Puyallup Tribe of Indians | Voters pamphlet only; not in city bio; no role/dates | S — verify |
| Mary Bridge grief facilitator, 8 years | Repeated in bio, Chamber, voters pamphlet | S — corroborated by repetition, not records |
| Continuum of Care Board; PIT count | Voters pamphlet only | S — verify |

---

## 4. Business and professional footprint

### 4.1 Real estate license and brokerage

- **Licensed Washington real estate broker since 2011.** LinkedIn certification: “Real Estate Broker, Washington State Department of Licensing (2011).” Official bio: “licensed real estate broker.” [C: LinkedIn + official bio.]
- **HomeLight agent profile** lists him as a **Real Estate Agent at Terry Wise & Associates**: 16 years of experience, 50 transactions, $354K average price point, 44 single-family homes, 3.7/5 from three reviews. [C: HomeLight; the page may be stale. Current DOL affiliation not independently confirmed; the DOL lookup was blocked by reCAPTCHA in this session.]
- **“16 years”** is consistent with a 2011 license and his May 4, 2026 statement. [C]
- **Current affiliation.** The F-1's business-customer section lists **Terry Wise & Associates** for “Consulting”; the podcast credits name **terrywisere.com** as production partner. Whether he is still an active agent at Terry Wise & Associates, or has moved to another brokerage, is an open item. [U]

### 4.2 The Terry Wise cluster

This is the most important network in the profile. The same name appears in five roles:

1. **Former employer / brokerage.** Lindholm was CEO of Terry Wise & Associates; HomeLight lists him as an agent there. [C]
2. **Campaign donor.** Terry Wise gave **$2,400** in two $1,200 contributions on 2025-03-24; Terry Wise & Associates gave **$200 in-kind** on 2025-08-18. [V: PDC; E059.]
3. **Podcast production partner.** The Informed Citizen's YouTube description: **“Produced in partnership with https://terrywisere.com”**; **“Editing & Post-Production: Tony Wise at https://www.wisevideography.com.”** [V: YouTube description; E070.]
4. **F-1 business customer.** The 2025 F-1 lists **Terry Wise & Associates** under the business-customer section for **“Consulting.”** The PDC instruction defines that section as payments of **$12,000 or more** in the aggregate. [C: F-1 + PDC instruction; E047/E060.]
5. **Solberg consultant.** Wise represented the owner of 5105 Solberg Dr SW, the property whose abatement contract Lindholm abstained on. [V: video; E056.]

**The tension.** On April 6, 2026, Lindholm said he did **not** have a “professional relationship” with Wise, only a friendship and former colleagueship. The F-1 lists a consulting payment from Wise's firm; HomeLight lists him as an agent at Wise's brokerage; the podcast is produced in partnership with Wise's real estate company. A literal reading of “no professional relationship” is hard to square with those records. He may have meant “no current professional relationship on the Solberg matter,” or the F-1 entry may be historical. The right-of-reply must ask him to reconcile the statements. [I: the contradiction is the story; do not assert perjury or dishonesty.]

**What is not claimed.** There is no evidence of a quid pro quo, bribery, or a payment tied to the abstention. The abstention itself was the correct procedural response to a conflict. The story is about the accuracy and completeness of the disclosure, not a crime. [I]

### 4.3 Concord Counsel

- **Founder and CEO; Chief Mediator.** Services: mediation; tribal law (real estate and family law “exclusively in certain tribal courts where appropriately barred”); community relations. [V: concordcounsel.com.]
- **Address:** 705 S 9th St, Tacoma, WA 98405 (Chamber listing); phone (253) 234-4686; website concordcounsel.com. The same 705 S 9th St, Suite 102, was sold to **Terry Wise** for $200,000–$499,999 per the F-1. The Chamber listing may predate the sale; whether Concord Counsel still occupies the suite or pays rent to Wise is an open question. [C: Chamber + F-1; U: current occupancy.]
- **Entity status.** No Washington SOS corporation/LLC record was retrievable under “Concord Counsel” (the CCFS public search returned zero even for control queries, so the search is unreliable). It may be a trade name/sole proprietorship of Washington Ventures Management or Lindholm personally. [U: SOS/DOR records.]
- **F-1 omission.** Concord Counsel is not named among the business associations on the 2025 F-1. It may be a trade name of Washington Ventures Management, an inactive business, or an unregistered sole proprietorship. This is a question, not a violation. [V absence; U reason.]
- **Assessment.** The mediation/tribal-law practice is a legitimate small business and a plausible bridge between his academic, chaplain, and legal interests. The open questions are entity status, current office occupancy, and whether the business is properly disclosed. [I]

### 4.4 Tribal court practice

- **Puyallup Tribal Court:** listed as **“Lindholm Philip M., 5409 100th St. SW, Box 39192, Lakewood, WA 98499, 206-659-5960, Advocate, Bar No. 585.”** The list is a “courtesy list for the public of Attorneys/Advocates admitted to practice before the Court,” voluntary and not all-inclusive. [V: Puyallup Tribal Court Courtesy Bar List, Jan. 6, 2026; E063.]
- **Swinomish and Makah:** the campaign/official site says “Barred in Puyallup, Swinomish, and Makah Tribal Courts.” No public roster entry for Lindholm was located for Swinomish or Makah. Both tribes' codes allow non-attorney advocates; the Makah code requires good moral character, court approval, and the Spokesman's oath; Swinomish has a tribal bar and a law-student/lay-advocate pipeline. [S/U: official site; tribal codes.]
- **Advocate vs. attorney.** The Puyallup list's “Advocate” designation is precise: he is admitted to practice before that court as an advocate, not listed as a Washington State Bar Association attorney. His campaign says “barred,” which is accurate for tribal court admission; the public may hear “lawyer.” The profile should explain the distinction without alleging misrepresentation. [V: court list; I: perception analysis.]
- **Law school.** The 2025 voters pamphlet says **JD in progress at Seattle University School of Law**; his X bio says “Law Student.” This is consistent with a law-student/advocate pathway. [V: pamphlet text; S: self-reported; U: current enrollment.]
- **Tacoma Prosecutor's Office; Puyallup Tribe of Indians.** The voters pamphlet lists both under professional experience, but the city bio does not. The roles and dates are unknown. [S/U: voters pamphlet; ask.]

### 4.5 Entities and ownership

| Entity | Ownership per 2025 F-1 | Role / notes | Grade |
|---|---|---|---|
| 8814-8815 Lochburn Lane SW Lakewood LLC | **84%** | Taxpayer of record for the 8814-8815 Lochburn apartment complex; other 16% not identified in public filing | V: F-1 + ATIP |
| Wyoming Housing Holding Company | **100%** | Wyoming entity; F-1 operating name “Community for Philip Lindholm,” same as campaign committee; likely a holding company | V as filed; U purpose/operating name |
| Washington Ventures Management | **100%** | F-1 business-customer entry for Terry Wise & Associates “Consulting” sits under this entity | V; C for relationship |
| Concord Counsel | Not listed | Founder/CEO; mediation/tribal law/community relations; may be trade name or sole proprietorship | V absence; U status |
| Community for Philip Lindholm | Campaign committee | PO Box 39192; same name as Wyoming Housing Holding's operating name | V: PDC/campaign |

**Why a Wyoming holding company?** Wyoming LLCs are commonly used for privacy and asset protection; the structure is lawful and common among real estate investors. It is relevant because it obscures the ownership chain of the Lakewood apartment complex and because the F-1 lists the campaign committee's name as the operating name. Do not imply illegality. [I: context.]

### 4.6 Rental property portfolio

- **8814-8815 Lochburn Ln SW, Lakewood.** The parcel's taxpayer is **8814-8815 Lochburn Lane Southwest Lakewood LLC**; F-1 ownership 84%. The property is an apartment complex with two buildings (8 and 10 units), built 1956, sold for **$1.85M** on 2018-12-06. Current listings describe 1-bed units from **$825** and 2-bed units from **$1,197**; **Spinnaker Property Management** is the contact. [V: ATIP + F-1; C: Redfin/listings; E048.]
- **107-109 Lake Louise Dr SW.** Duplex; F-1 lists it as real estate; the record owner is a trust/LLC (Wyoming Woopie LLC TTEE of 107 to 109 Lake Trust); advertised as a rental covering 103-109. Specific unit rental status is unverified. [C: F-1 + ATIP + listing; E049.]
- **9908 Meadow Rd SW.** 6-bed, 4,650 sq ft home; assessed at $1M+; taxpayer 9908 Meadow Rd SW Lakewood LLC. Likely his residence; the parcel record is on file (E050). Treat the address as public-record but not automatically publishable; apply a privacy review before any publication. [C: ATIP; E050.]
- **Seven properties total** per the F-1; the public extract identifies the three above plus a 2024 F-1 property at 1546 Reservation Rd SW, Olympia. The remaining properties are not enumerated in the public JSON extract. [V: F-1 count; U: full list.]
- **Tenant/eviction record.** A LINX search for “Lochburn” returned three cases involving entities with similar names: *Lochburn Gardens Properties LLC v. Brownie Stevens* (10-2-15882-6, 2010), *Lochburn Lane LLC v. Kamali E. Dunning* (14-2-06652-5, 2014), and *Kennedy v. Lochburn Lane LLC* (8Z906310C, District Court, 2018). **None has been tied to Lindholm's current LLC.** The current entity is “8814-8815 Lochburn Lane Southwest Lakewood LLC,” not “Lochburn Lane LLC” or “Lochburn Gardens Properties LLC.” Do not attribute these cases to Lindholm without SOS/ownership records. [V: case existence; U: ownership link.]
- **Assessment.** The rental portfolio is the clearest financial conflict surface: he votes on rental-housing policy, owns an 84% stake in an apartment complex listed as 18 units in the city, and has not disclosed that ownership in the minutes reviewed. The votes may be perfectly lawful; the disclosure gap is the story. [I]

### 4.7 Private notes receivable

The 2025 F-1 lists private notes receivable from **Jacob Lawrence** ($200K–$499K; reported income $100K–$199K), **Camber Grant**, **Craig Wright**, **Andy Tran**, **Tim Gurule**, and **Luke and Andrew Butler**. [V: F-1.]

**The Lawrence lawsuit.** Jacob Lawrence is the plaintiff in the active Consumer Protection Act case against Lindholm (26-2-08192-7). The F-1 shows a note receivable from a Jacob Lawrence; the identity match between the F-1 note and the lawsuit plaintiff is **not confirmed**. If confirmed, the lawsuit may relate to that note or to a business transaction connected to it. This is an inference, not a finding. [V: docket + F-1; I: possible link; U: complaint.]

### 4.8 Campaign finance and donor network

- **Reported totals:** $33,805 raised / $33,000 spent in the case file's final report; the News Tribune reported $24,845 raised / $13,591 spent as of July 2025. [C: PDC/case file; verify final C-4.]
- **Verified real estate/landlord/construction floor: $6,300** — Terry Wise $2,400; Landlord Solutions $1,200; Master Builders Pierce $1,200; WA Realtors PAC $500; Rémy Claude $1,000; plus $200 in-kind from Terry Wise & Associates. [V: PDC; E059.]
- **Collapsed/unverified:** Stonegate Associates LLC ($2,000) and Capital Ventures/McKinley Sands ($2,400/$2,400) were previously counted but failed verification; do not include them in the floor. [V: matrix LDD-26.]
- **Endorsements:** the establishment slate listed in §3.2. The endorsement network is bipartisan and includes the mayor he succeeded, two former mayors, the deputy mayor, two council colleagues, the former sheriff, and the former police chief. [V: voters pamphlet/News Tribune.]
- **Assessment.** The donor floor is modest for a local race, and the real estate money is not unusual for a landlord/broker candidate. The significance is the **overlap** with his employer/podcast partner, not the dollar amount. [I]

### 4.9 The Cascadian — media ownership

- **Co-founder.** The Cascadian's About page: “**Co-founders: Philip Lindholm and Walter Neary**.” It says Lindholm ran for and won the same council seat Neary held in 2003; “Now, Philip and Walter are joining forces to build *The Cascadian* as a 501(c)(3) nonprofit.” [V: The Cascadian About; E065.]
- **The Seattle Times** (Brier Dudley): “Now retired, Neary started The Cascadian with Phil Lindholm, a mediator and podcaster recently elected to the Lakewood City Council.” The paper described the outlet at launch as an “online bulletin board” that did not plan original reporting, modeled on The Suburban Times. [V: Seattle Times; E066.]
- **Editors:** Walter Neary and Steve Dunkelberger. The About page says team members who publish do so “as individuals and not representing The Cascadian.” [V: About page.]
- **Nonprofit:** **Cascadian Media**, 501(c)(3), EIN **41-2787967**, Lakewood WA, NTEE **A30** (Media, Communications Organizations); the outlet says it incorporated January 7, 2026. No Form 990 is available yet. [V: ProPublica/IRS BMF; E067.]
- **Address:** PO Box 39192, Lakewood, WA 98496 — the same PO Box used by Lindholm's campaign and Concord Counsel. Whether this is shared operations or a mailbox service is not established. [V: Cascadian support page + campaign/Chamber.]
- **His columns:** “The Boy on the Bus” (Caring for Kids) and “A Story Worth Telling” (Korum Ford/Lakewood Playhouse) are published on The Cascadian; the latter says he is a member of the Playhouse Board. [V: thecascadian.com; E077.]
- **Why it matters.** A sitting councilmember is a co-founder of a local news outlet that covers his city, publishes his columns, and shares his campaign PO Box. The outlet discloses the co-founder role and says contributors publish as individuals; its editors are experienced journalists. This may be a legitimate civic-media experiment, but it is a media-ownership interlock that readers and voters should know about. The open questions are editorial firewall, board independence, and whether he participates in coverage decisions. [V facts; I analysis; U governance.]

### 4.10 The Informed Citizen podcast — media production

- **Scale:** YouTube channel **117K subscribers, 377 videos, 1,518,275 views**, joined September 16, 2011. [V: YouTube page; E069.]
- **Content:** long-form interviews and shorts on homelessness, immigration, marriage/gender, human trafficking, American identity, and local politics. Episode 31: “Should Immigration Be Easy?” with Nirvana's Krist Novoselic and State Sen. Yasmin Trudeau (41K views); Episode 29: “Love OR Marriage” with Stephanie Coontz (42K); Episode 28: “Can America Last?” with Lt. Gov. Denny Heck and Hans Zeiger (51K); Episode 26: homelessness (23K). [V: YouTube listings.]
- **Production credits:** “Produced in partnership with https://terrywisere.com”; “Editing & Post-Production: Tony Wise at https://www.wisevideography.com.” [V: YouTube description; E070.]
- **In-kind support:** the F-1/campaign filings report **$200 in-kind from Terry Wise & Associates** for podcast production. The fair-market value is not established; $200 is unlikely to reflect the full cost of editing/production if the partnership is ongoing. This is a question, not a finding. [V: PDC; I: valuation question; U: FMV.]
- **Monetization:** YouTube channels with 100K+ subscribers are eligible for monetization; the channel has a “100K subscribers” award post. The F-1's income section does not list YouTube/ad revenue. It may be below the F-1 threshold, held by an entity, or not monetized. This is an open question. [V: channel size/award; U: revenue.]
- **Why it matters.** The podcast is a significant media asset with a production relationship to the same brokerage/donor at the center of the Solberg conflict. It is also a political platform: the host interviews elected officials and policy figures while serving on the council. Disclosure and in-kind valuation are the accountability questions. [I]

### 4.11 Law school and professional trajectory

- **JD in progress, Seattle University School of Law** (2025 voters pamphlet); **BA in progress, UW Tacoma** (same). [V: pamphlet text; S: candidate-supplied; U: current enrollment.]
- **X bio:** “CEO. Planning Commissioner. Law Student. Seattle.” [S: X profile.]
- **Timeline implication:** if he is in law school while serving on the council, running Concord Counsel, managing rental property, and producing a podcast, the workload is extraordinary. It also explains the “Advocate” tribal-court status and the “Tacoma Prosecutor's Office” line (likely an internship/externship, but unverified). [I]
- **Do not claim** he is a lawyer, a WSBA member, or a licensed attorney. The records show an advocate admission, not a bar license. [V: Puyallup list; U: WSBA status not checked.]

---

## 5. Legal and regulatory record

### 5.1 Active Consumer Protection Act lawsuit — *Lawrence v. Lindholm*

| Field | Value | Grade |
|---|---|---|
| Case | Jacob Lawrence v. Philip Lindholm | V: LINX |
| Cause No. | 26-2-08192-7 | V |
| Court | Pierce County Superior Court, Dept. 7 (Judge Diana Lynn Kiesel) | V |
| Case type | **Consumer Protection Act** | V |
| Filed | April 29, 2026 | V |
| Plaintiff | Jacob Lawrence; attorney John Cummings (WSBA 40505) | V |
| Defendant | Philip Lindholm; attorney Thomas F. Gallagher (WSBA 24199) | V |
| Complaint | 62 pages; public; not obtained | V (filing); U (contents) |
| Answer | August 13, 2026; amended answer November 4, 2026 | V |
| Jury | 12; jury demand September 1, 2026 | V |
| Trial | April 28, 2027; pretrial April 14, 2027; discovery cutoff March 10, 2027 | V |

**What the docket establishes:** a consumer-protection claim is pending; both sides are represented; the case is on a standard track with a jury demand and a 2027 trial date. **What it does not establish:** the allegations, the amount in controversy, or the merits. The complaint is 62 pages and public; it should be purchased from the Pierce County Clerk or requested under the public records act before any characterization. [V docket; U complaint.]

**Possible link to the F-1.** The 2025 F-1 lists a private note receivable from **Jacob Lawrence** ($200K–$499K; reported income $100K–$199K). If the plaintiff is the same Jacob Lawrence, the lawsuit may involve that note or a related transaction. The identity match is not confirmed; the complaint will show. [V: F-1; I: possible link; U: confirmation.]

**Defense counter-argument (anticipated):** “A pending lawsuit is not evidence of wrongdoing; the plaintiff bears the burden; the case may be a commercial dispute, not a consumer-protection violation; the F-1 note is unrelated.” **Answer:** the dossier does not treat the lawsuit as proof; it flags a live public-record fact that bears on the subject's business conduct and should be put to him for comment. The complaint's allegations must be quoted verbatim if used. [I: litigation-risk analysis.]

### 5.2 2018 State Farm personal injury suit

- *Philip M. Lindholm v. State Farm Insurance Company*, 18-2-07177-7, Pierce County Superior Court, **Personal Injury**, filed April 10, 2018; settled by arbitration July 23, 2019; dismissed with prejudice September 10, 2019. [V: LINX; E072.]
- No details of the injury or settlement are in the public docket summary. It is a closed personal matter; include only if relevant to the profile's narrative (e.g., the grief/TEDx story), and do not imply wrongdoing. [V docket; U details.]

### 5.3 No criminal, tax, or district civil cases — as searched

- LINX searches for “Lindholm, Philip” (2010–2026) returned **0** Superior Court criminal cases, **0** District Court criminal cases, **0** tax warrant/judgment cases, and **0** District Court civil cases. [V: search results; E073.]
- The index warns that names cannot be associated with individuals without case research and that the data is not a complete criminal-history record. Phrase as “the public index returned no cases,” not “he has no record.” [V caveat.]
- This is a meaningful due-diligence result for a public official; it should be reported with the methodological caveat, not as an exoneration. [I]

### 5.4 Lochburn-related court records — unverified ownership link

- *Lochburn Gardens Properties LLC v. Brownie Stevens*, 10-2-15882-6 (2010).
- *Lochburn Lane LLC v. Kamali E. Dunning*, 14-2-06652-5 (2014).
- *Kennedy v. Lochburn Lane LLC*, 8Z906310C (District Court, 2018; Lochburn Lane LLC as defendant).
- The current owner entity is **8814-8815 Lochburn Lane Southwest Lakewood LLC**. The relationship between the older “Lochburn Lane LLC” / “Lochburn Gardens Properties LLC” and the current LLC is **not verified**. Do not attribute these cases to Lindholm. [V case existence; U ownership.]
- **Why it matters.** If the current LLC or its predecessor has a tenant-dispute history, that is relevant to the landlord profile. The records request should include the LLC's full case history and the property's rental registration/inspection file. [I]

### 5.5 Tribal bar records

- **Puyallup:** verified Advocate Bar No. 585. [V: E063.]
- **Swinomish:** claimed; no public roster entry found. The tribe has a tribal bar and a lay-advocate/law-student pathway. [S/U]
- **Makah:** claimed; the Makah Law and Order Code allows admission to the Tribal Court Bar without a state bar exam (good moral character, court approval, Spokesman's oath). [S/U]
- **Significance:** the tribal-court practice is a real credential, but it is not the same as a Washington law license. The profile should use “tribal-court advocate” and quote the court's designation. [V/I]

### 5.6 DOL, SOS, WSBA — open status

- **DOL real estate license:** claimed since 2011; LinkedIn/HomeLight corroborate; the DOL public lookup was blocked by reCAPTCHA in this session. The license number/status/current firm should be pulled by records request or a browser session with the advanced search working. [U]
- **SOS business entities:** the CCFS public search returned zero even for control queries (“Starbucks”), so it is not usable in this session. No reliable SOS record for Concord Counsel, Lochburn LLC, Washington Ventures Management, or Cascadian Media was obtained. Use the DOR business lookup, the Digital Archives, or a direct records request. [U]
- **WSBA:** no attorney license was checked. The Puyallup list says “Advocate,” not “Attorney”; the profile should not assert a WSBA status either way without a directory search. [U]

---

## 6. Social media and public communications

### 6.1 Platform map (as of 2026-11-13)

| Platform | Handle / URL | Followers / scale | Bio / positioning | Grade |
|---|---|---|---|---|
| YouTube | @drphiliplindholm | **117K subscribers; 377 videos; 1,518,275 views; joined 9/16/2011** | “Discussing the issues that matter most with Dr. Philip Lindholm” | V: platform |
| Podcast | The Informed Citizen (theinformedcitizen.com) | YouTube + audio platforms | Long-form interviews; produced in partnership with terrywisere.com | V: credits |
| X | @philipmlindholm | Not captured | “CEO. Planning Commissioner. Law Student. Seattle” | S: profile |
| Instagram | @drphiliplindholm | 1,696 followers; 2,086 following | “Community & Government Relations; Councilmember; Host, Informed Citizen; All views here are my own” | S: platform |
| TikTok | @drphiliplindholm | Not captured | “Mediator, Councilmember, Informed Citizen Podcast Host” | S: profile |
| Facebook | /drphiliplindholm | 2,492 followers | “Community Relations; Councilmember; Host, Informed Citizen Podcast. All views expressed are my own.” | S: platform |
| LinkedIn | /in/drphiliplindholm | 901 followers | “Candidate for Lakewood City Council; Mediator; Veteran” | S: platform |
| Website | philiplindholm.com; votephilip.com | — | Campaign/official site; NationBuilder | V: site |
| The Cascadian | thecascadian.com | New outlet; 501(c)(3) | Co-founder; columns | V: About/Seattle Times |

### 6.2 YouTube / podcast

- The channel is the dominant platform: 117K subscribers and 1.5M views, with a 100K-subscriber award post. It has been active since 2011, well before the campaign. [V]
- The content is not local-government-only. It is a general-audience interview show on homelessness, immigration, marriage/gender, human trafficking, American identity, and policy. The guests range from Nirvana's Krist Novoselic and State Sen. Yasmin Trudeau to Lt. Gov. Denny Heck and Stephanie Coontz. [V]
- The production partnership with Terry Wise Real Estate and editor Tony Wise is disclosed in the video descriptions. [V]
- **Assessment:** the podcast is a genuine media property, not a campaign website. It gives Lindholm an independent audience and a platform to interview officials who may later appear before the council. That is a conflict surface, but it is also a form of civic media. The accountability question is disclosure, not existence. [I]

### 6.3 X

- Bio: “CEO. Planning Commissioner. Law Student. Seattle.” The “Planning Commissioner” title is outdated (he is now a councilmember); the “Law Student” title is consistent with the voters pamphlet. [S]
- Posts include podcast episodes on human trafficking, immigration, “1776,” and an “Unboxing YouTube Award for 100K Subscribers” post. [S: search snippets]
- **Use:** self-published; use for stated positions and biography, not for factual assertions about others. [I]

### 6.4 Instagram

- Bio: “Community & Government Relations; Councilmember; Host, Informed Citizen; All views here are my own.” [S]
- Posts include the Puyallup Tribe's success, UW Tacoma's Legal Pathways Program, and podcast clips. [S: search snippets]
- The UW Tacoma post (“We spoke honestly about what law…”) is consistent with the law-student identity. [S]

### 6.5 TikTok

- Bio: “Mediator, Councilmember, Informed Citizen Podcast Host.” [S]
- Short clips on immigration, divorce, and podcast moments. [S]
- **Use:** distribution channel, not a primary record. [I]

### 6.6 Facebook

- 2,492 followers; bio as above. [S]
- Public videos include “Are all Americans chasing the same dream?” (3.4K views), “What Makes America Different?” (1.1K), and “Should Women Stay Home While Men Work?” (5.7K). [S: search snippets]
- Campaign videos and the kickoff speech are also posted. [S]
- **Use:** the Facebook page is the most campaign-oriented platform; it shows the cultural/policy content that drives engagement. [I]

### 6.7 LinkedIn

- 901 followers; headline “Candidate for Lakewood City Council; Mediator; Veteran.” [S]
- Certifications: Real Estate Broker (WA DOL, 2011); Board Certified Chaplain (NAVAC, 2019); Certified Mediator (Pierce County DRC, 2026). [S: LinkedIn]
- Publications: *Latter-day Dissent* (Blackwell, 2011); *Voyeur: Notes of Disquiet* (Kofford, 2011); “The Struggle Within” in *Metallica and Philosophy* (2007); “Stu Ungar & Emmanuel Levinas” (2006); a review in *Levinas & Biblical Studies*. [S: LinkedIn; books corroborated elsewhere.]
- Recent activity includes shares of podcast clips on marriage/gender and likes of political content (Jack Miller Center, Obama, a Snohomish County councilmember, a prosecutor's fentanyl post, Gary Locke on budget discipline). [S: LinkedIn activity]
- **Use:** LinkedIn is the best source for certifications/publications; the activity feed is a signal of his political/content interests, not a reliable statement of beliefs. [I]

### 6.8 The Cascadian columns

- “The Boy on the Bus” — a column about Diane Formoso and Caring for Kids; ends “Philip Lindholm is a mediator and Lakewood City Councilmember.” [V: The Cascadian]
- “A Story Worth Telling” — a column about Korum Ford donating a van to the Lakewood Playhouse; he identifies himself as a member of the Playhouse Board. [V: The Cascadian]
- The columns are community-service storytelling, not policy advocacy. They reinforce the “quiet kindness”/civic-booster persona. [I]

### 6.9 Content themes and political signalling — analysis

- **Themes:** homelessness, public safety, downtown revitalization, military families, immigration, marriage/gender, American identity, human trafficking, addiction, grief.
- **Style:** interview-driven, non-confrontational, “solutions” framing; the podcast tagline is “real-world solutions to the challenges facing our world.”
- **Political positioning:** the endorsement coalition is bipartisan-establishment (Whalen, Anderson, Richardson, Moss, Bocchi, Pearson, Pastor, Zaro). The guest list spans the political spectrum — progressive (Novoselic, Trudeau, Coontz), Marxist (Richard Wolff), liberal-internationalist (Larry Diamond), heterodox (Peter Boghossian), and center-right (Hans Zeiger). He is best described as a nonpartisan/centrist civic entrepreneur, not a partisan. [I: analysis from guest list/endorsements; do not label him in copy without his own words.]
- **Risk:** the culture-war-adjacent clips (“Should Women Stay Home While Men Work?”, “What Makes America Different?”) may be algorithm-driven engagement content, not policy positions. Do not infer beliefs from clip titles. [I]

---

## 7. Network map

### 7.1 The Terry Wise cluster (core)

```
Terry Wise
├── Terry Wise & Associates (brokerage) ── Lindholm: former CEO / agent (HomeLight)
├── Campaign: $2,400 to Lindholm + $200 in-kind from the firm
├── Podcast: "Produced in partnership with terrywisere.com"; Tony Wise edits
├── F-1: business-customer "Consulting" payment to Washington Ventures Management
└── Solberg: Wise represents the owner of 5105 Solberg Dr SW
        └── Lindholm abstains on the $71,181.85 abatement contract
```

**Grade:** each link is V/C; the *combination* is the story. There is no evidence of a quid pro quo. [V links; I pattern.]

### 7.2 Political endorsers

| Name | Role | Relationship | Grade |
|---|---|---|---|
| Jason Whalen | Mayor (predecessor); now Auburn city attorney | Endorsed Lindholm for his seat | V: voters pamphlet/News Tribune |
| Don Anderson | Former Lakewood mayor | Endorser | V |
| Doug Richardson | Former Lakewood mayor | Endorser | V |
| Mary Moss | Deputy Mayor (retiring) | Endorser | V |
| Paul Bocchi | Councilmember, now Mayor | Endorser | V |
| Ryan Pearson | Councilmember | Endorser | V |
| Paul Pastor | Former Pierce County Sheriff | Endorser | V |
| Mike Zaro | Former Lakewood Police Chief | Endorser | V |
| Alyssa Anderson Pearson | School Board President | Endorser | V |
| Rotary presidents; local business owners | Civic/business | Endorsers | V (as stated) |

**Assessment:** the endorsement coalition is the Lakewood establishment, across party lines. It explains his 2025 win and his access to the council's inner circle. It also means his conflicts are embedded in the same network that endorsed him, which makes external accountability more important. [I]

### 7.3 Media/civic network

- **Walter Neary** — co-founder of The Cascadian; former Lakewood councilmember (2003); retired journalist (The Olympian, The Lakewood Journal). [V]
- **Steve Dunkelberger** — co-editor of The Cascadian; historian; co-author with Neary. [V]
- **Lakewood Rotary / Steilacoom Kiwanis** — civic membership. [S]
- **Pierce County Dispute Resolution Center** — mediator certification/affiliation. [C]
- **Mary Bridge Hospital** — grief-group facilitator (8 years). [S]
- **Lakewood Playhouse Board** — board member (self-described). [S]
- **Continuum of Care Board / PIT count** — homelessness governance. [S]

### 7.4 Tribal/business network

- **Puyallup Tribal Court** — Advocate Bar No. 585. [V]
- **Swinomish / Makah** — claimed admissions. [S/U]
- **Spinnaker Property Management** — manager/contact for the Lochburn apartments. [C: rental listings]
- **Wyoming Housing Holding Company / Washington Ventures Management** — his entities. [V]
- **Concord Counsel** — his mediation practice. [V]

### 7.5 What the network map shows

The network is not a shadowy cabal; it is a small-city civic/professional network in which the same people appear as employers, donors, podcast partners, clients, endorsers, and colleagues. The density is the story: in a part-time, nonpartisan council system, the lines between public service, business, and media are thin, and the disclosure rules depend heavily on the official's own judgment. [I: systemic frame.]

---

## 8. Timeline

| Date | Event | Grade |
|---|---|---|
| December 10 (year not public) | Born, Seattle | V (date/place); U (year) |
| Late 1990s | Leaves high school; Green River CC at 17; AA; Central Washington (two BAs) | S |
| 2000s | Oxford (three master's, DPhil); Paris (2005); Juilliard (2007); BBC/ITV; Rhodes finalist | C/S |
| 2010 | Oxford doctorate | C |
| 2011 | Real estate license; *Latter-day Dissent* and *Voyeur* published; YouTube channel joined (9/16) | C/V |
| 2013 | Whiskey N' Rye formed | C |
| 2017 (Jan 29) | Begins as 194th Wing chaplain, Camp Murray | V: DVIDS |
| 2018 (Apr 10) | *Lindholm v. State Farm* personal injury suit filed | V: LINX |
| 2018 (Dec 6) | Lochburn apartment complex sold for $1.85M | V: ATIP/Redfin |
| 2019 | TEDx talk; NAVAC chaplain certification; State Farm case dismissed | V/C |
| 2024 | Planning Commission service (exact date TBD) | S/U |
| 2025 (May 1) | Campaign kickoff speech | V: YouTube |
| 2025 (Aug 5) | Primary; voters pamphlet lists JD in progress | V |
| 2025 (Nov 4) | General election win (case file: 59.4%) | C |
| 2025 (late) | The Cascadian launches | V: Seattle Times/About |
| 2026 (Jan) | Takes office; Cascadian Media incorporates (Jan 7) | V |
| 2026 (Mar 23) | 2025 F-1 filed (statement 132557) | V |
| 2026 (Apr 6) | Solberg abatement contract; Lindholm abstains | V |
| 2026 (Apr 29) | *Lawrence v. Lindholm* CPA suit filed | V: LINX |
| 2026 (May 4) | Ordinance 849 rental-housing vote | V |
| 2026 (Aug 13 / Nov 4) | Answer / amended answer in Lawrence | V |
| 2027 (Apr 28) | Trial date in Lawrence | V |

---

## 9. What the record supports — and what it does not

### 9.1 Verified facts (may publish)

1. Lindholm is the Lakewood City Councilmember for Position 3, elected in 2025, term through 2029. [V]
2. His 2025 F-1 reports 84% of 8814-8815 Lochburn Lane SW Lakewood LLC, 100% of Wyoming Housing Holding Company, and 100% of Washington Ventures Management. [V]
3. The Lochburn LLC is the taxpayer of record for the 8814-8815 Lochburn apartment complex; the property is an apartment complex with two buildings (8 and 10 units), built 1956, sold for $1.85M in 2018. [V/C]
4. He abstained on Motion 2026-25, the $71,181.85 Solberg abatement contract; the contract passed 6–0. [V]
5. Terry Wise represented the Solberg owner; Michelle Le said she is the owner; the minutes described her as a “Lakewood resident” and omitted her ownership statement. [V]
6. Lindholm said he had no “professional relationship” with Wise, only a friendship and former colleagueship. [V]
7. His 2025 F-1 lists Terry Wise & Associates under the business-customer section for “Consulting.” [C]
8. He received $2,400 from Terry Wise and $200 in-kind from Terry Wise & Associates. [V]
9. The Informed Citizen's YouTube description says it is produced in partnership with terrywisere.com and edited by Tony Wise. [V]
10. The Puyallup Tribal Court lists him as an Advocate, Bar No. 585. [V]
11. He is a co-founder of The Cascadian; the outlet is a 501(c)(3) with EIN 41-2787967; its PO Box matches his campaign. [V]
12. He is the defendant in *Lawrence v. Lindholm*, a pending Consumer Protection Act case filed April 29, 2026, with a trial set April 28, 2027. [V]
13. The public court index returned no criminal, tax, or district civil cases for “Lindholm, Philip” 2010–2026. [V search result]
14. His YouTube channel reports 117K subscribers, 377 videos, and 1.5M views. [V]

### 9.2 Corroborated (may publish with attribution)

1. He was a real estate broker at Terry Wise & Associates; HomeLight lists 16 years, 50 transactions, $354K average, 44 single-family homes. [C]
2. He was an Air Force captain/chaplain; DVIDS confirms the 194th Wing chaplain role; the rank is from his bio/Amazon. [C]
3. He has an Oxford doctorate and three master's degrees; multiple bios agree; no thesis record. [C]
4. He is a singer-songwriter/filmmaker; AllMusic/Wikipedia/Discogs corroborate. [C]
5. He is a board-certified chaplain and mediator; LinkedIn certifications. [C]
6. His campaign raised at least $6,300 from verified real estate/landlord/construction interests. [V floor]
7. He won the 2025 general election; the exact percentage needs the canvass. [C]

### 9.3 Self-reported or single-source (attribute, do not present as fact)

1. “Rhodes Scholar finalist.” [S]
2. “High honors” at Central Washington. [S]
3. Oxford thesis title/advisor details beyond the doctorate. [S]
4. “Tacoma Prosecutor's Office” and “Puyallup Tribe of Indians” roles. [S]
5. Swinomish and Makah tribal bar admissions. [S]
6. Mary Bridge grief-group facilitator for eight years. [S — repeated, but no records]
7. Continuum of Care Board / PIT count. [S]
8. Lakewood Playhouse Board. [S]
9. “JD in progress” / “BA in progress.” [S — in an official pamphlet, but candidate-supplied]
10. The “16 years” real estate experience is consistent with the 2011 license but is his own statement. [S/C]

### 9.4 Inferences (label, never assert as fact)

1. The Lawrence lawsuit may relate to the Jacob Lawrence note receivable on the F-1. [I]
2. Lindholm's “no professional relationship” statement is hard to reconcile with the F-1 consulting payment and the podcast partnership, unless he meant “no current relationship on the Solberg matter.” [I]
3. The $200 in-kind podcast production is likely below fair-market value if the partnership is ongoing. [I]
4. The Cascadian's shared PO Box and co-founder role create a media-ownership interlock, even if the outlet has an editorial firewall. [I]
5. The rental-housing votes were informed by his landlord experience; whether they were *motivated* by it is not provable from the record. [I]
6. The “Advocate” designation may be misheard as “attorney” by the public; the record does not show he claimed to be a lawyer. [I]

### 9.5 What is not claimed

- No evidence of bribery, quid pro quo, or a crime.
- No proof that the Solberg abstention was traded for campaign support.
- No proof that he concealed his rental ownership; only that no disclosure appears in the public minutes/video.
- No proof that he is not a lawyer; the record shows an advocate admission, and he is a law student.
- No proof that The Cascadian is a propaganda outlet; it is a new nonprofit community outlet with experienced editors.
- No proof that the Lawrence lawsuit has merit; it is a pending complaint.
- No proof that the Lochburn-related 2010/2014/2018 cases involve his current LLC.

---

## 10. Story angles and systemic frame

### 10.1 The interlocking-roles story

A part-time councilmember is also a broker, landlord, mediator, tribal-court advocate, podcast host, and co-founder of a local news outlet. Each role is lawful. Together they create a **disclosure problem**: the public sees the official, not the portfolio. The story is about how a small city's ethics regime handles a person whose private roles touch nearly every policy area he votes on. [I: frame]

### 10.2 The Terry Wise cluster

The strongest documented conflict story. The same former employer/donor/podcast partner represented the client whose abatement contract Lindholm abstained on. The abstention was correct; the statement “I do not have a professional relationship” is the loose thread. The F-1's consulting payment and the podcast production credit give the statement a factual context the public did not hear at the meeting. [V links; I frame]

### 10.3 The media-ownership story

A councilmember co-founded a local news outlet, shares its PO Box with his campaign, and writes columns for it. The outlet has experienced editors and discloses the co-founder role; it may be a genuine civic-media experiment. The accountability questions are editorial firewall, board independence, and whether readers are told when the outlet covers him. This is a “how local news is reinvented — and who owns it” story. [V facts; I frame]

### 10.4 The rental-housing votes

Ordinance 849 added self-certification and an ADU exemption. Lindholm, an 84% owner of an apartment complex listed as 18 units, seconded the ADU amendment, voted to keep self-certification, and described “personal experience with the rental safety program.” No disclosure appears in the minutes/video. The story is whether a landlord-legislator should recuse or disclose on general rental-housing policy — a question that goes beyond one person. [V facts; I frame]

### 10.5 The lawsuit

A pending Consumer Protection Act case is a live accountability fact. If the complaint alleges misrepresentation in a loan or real estate transaction, it could be the strongest story in the file. Until the complaint is obtained, the dossier should say only that the case exists, the parties, the case type, and the trial date. [V docket; U complaint]

### 10.6 The credentials question

“Advocate” vs. “attorney”; “JD in progress”; “Rhodes finalist”; “Oxford doctorate”; “Air Force captain.” Most of the portfolio is documented; some of the superlatives are self-reported. The story is not “fake credentials” — it is how public bios accumulate unverified superlatives and how voters hear them. The campaign's “barred in three tribal courts” is accurate as far as Puyallup is concerned; the other two are unverified. [V/I]

### 10.7 The systemic frame — how the world works

Lakewood is a part-time, nonpartisan council-manager city. Its ethics code (LMC 1.32) relies on self-disclosure and recusal; the case file found **no independent ethics board**. The city attorney and city manager report to the council. In that structure, a councilmember's private network — employer, donors, clients, media partners — is not systematically visible. The case file's peer comparison found Lakewood's dual-government employment rate (5 of 7, 71%) far above the peer range (0–29%, median 14%), while 4 of 5 peer cities also lack an ethics board. The systemic point: Lakewood's ethics infrastructure is typical in its weakness, but its role density is an outlier. **Re-verify the peer comparison before publication.** [C: case file; I: frame]

---

## 11. Right-of-reply questions (expanded)

The existing 12 questions in `right-of-reply.md` remain. Add:

13. **The Lawrence lawsuit.** Please confirm that you are the defendant in *Jacob Lawrence v. Philip Lindholm*, Pierce County Superior Court No. 26-2-08192-7, and describe the nature of the dispute in your own words. Is the plaintiff the same Jacob Lawrence listed as a private note receivable on your 2025 F-1? If not, please explain.

14. **The Cascadian.** You are listed as a co-founder of The Cascadian with Walter Neary. What is your current role — founder, board member, columnist, adviser, or none? Do you participate in editorial decisions or coverage of the city council? How does the outlet disclose your council role and its shared PO Box with your campaign?

15. **The podcast production partnership.** The Informed Citizen's YouTube description says it is produced in partnership with terrywisere.com and edited by Tony Wise. Your F-1/campaign filings report $200 in-kind from Terry Wise & Associates for podcast production. Please describe the partnership, who pays for production, and how the $200 in-kind value was calculated.

16. **The “no professional relationship” statement.** You told the council you had no professional relationship with Mr. Wise. Your F-1 lists a consulting payment from Terry Wise & Associates; HomeLight lists you as an agent at his brokerage; your podcast is produced in partnership with his company. Please reconcile those records with your statement.

17. **Tribal court admissions.** The Puyallup Tribal Court lists you as an Advocate (Bar No. 585). Please confirm your admissions in Swinomish and Makah, the dates, and whether you are admitted as an attorney or an advocate in each. Are you currently enrolled at Seattle University School of Law?

18. **Tacoma Prosecutor's Office / Puyallup Tribe.** The 2025 voters pamphlet lists “Tacoma Prosecutor's Office” and “Puyallup Tribe of Indians” as professional experience. Please describe those roles, dates, and whether they were legal, policy, administrative, or internship positions.

19. **Current brokerage.** Are you currently licensed and affiliated with Terry Wise & Associates, or another brokerage? Please provide the current DOL license status and firm.

20. **The rental portfolio and tenant disputes.** Please confirm the full list of rental properties, the number of units, and whether any tenant disputes, eviction filings, or code-enforcement complaints have been filed against the Lochburn LLC or any other entity you control. Are you aware of the 2018 *Kennedy v. Lochburn Lane LLC* case, and is that entity related to your current LLC?

21. **The Cascadian's nonprofit governance.** Who serves on the board of Cascadian Media? Does the board include any city officials or campaign contributors? Will the outlet publish a disclosure when it covers you or your votes?

22. **Podcast revenue.** Does the YouTube channel or podcast generate advertising, sponsorship, or membership revenue? If so, how is it reported on your F-1?

---

## 12. Records requests and next steps

### 12.1 Court records

- **Purchase or request the 62-page complaint** in *Lawrence v. Lindholm*, 26-2-08192-7, and the answer/amended answer. The complaint is the single highest-value document in the file.
- Pull the **State Farm** case file only if the injury/settlement is relevant to the profile narrative.
- Pull the **Lochburn-related** case files and confirm the entity ownership chain (SOS/UBI).

### 12.2 Financial/entity records

- **PDC imaged F-1** for 2025 (statement 132557) and 2024 (122447) to get the exact Terry Wise consulting date/amount. Do not use the `docid` endpoint; request by statement/submission ID.
- **DOL real estate license** record: license number, status, current firm.
- **SOS/CCFS** entity records: 8814-8815 Lochburn Lane SW Lakewood LLC; Washington Ventures Management; Wyoming Housing Holding Company (Wyoming SOS); Cascadian Media; Concord Counsel (if registered).
- **UCC/lien filings** for Lindholm and the entities.
- **DOR business lookup** for Concord Counsel and the entities.
- **IRS Form 1023/990** for Cascadian Media (EIN 41-2787967); board/officers.

### 12.3 City records

- **Lakewood ethics advice/conflict memos** for Lindholm, 2026.
- **Solberg abatement file**: all communications with Wise, Le, and Lindholm; the contract procurement; the staff report; the council packet.
- **Rental registration/inspection records** for 8814-8815 Lochburn, 107-109 Lake Louise, and any other Lindholm-affiliated property.
- **Planning Commission attendance/vote record** 2024–2025.
- **Council committee/liaison assignments** for Lindholm.

### 12.4 Media/nonprofit records

- **The Cascadian** board/officers, bylaws, conflict-of-interest policy, donor list, and editorial firewall.
- **The Informed Citizen** production contracts, sponsorship agreements, and YouTube revenue (if public).
- **Lakewood Playhouse** board list (confirm his membership).

### 12.5 Verification before publication

- Rhodes Trust: confirm “Rhodes Scholar finalist.”
- Oxford ORA: confirm DPhil thesis/year.
- Seattle University Law: confirm current enrollment (or rely on the voters pamphlet with attribution).
- Swinomish/Makah: confirm bar admissions.
- WSBA: confirm whether he is or is not a licensed attorney.
- Pierce County canvass: confirm 59.4%.
- Peer comparison: re-verify the 5-of-7 dual-employment figure and the ethics-board comparison.
- F-1: confirm the exact Wise consulting amount/date and the full seven-property list.

---

## 13. Source appendix (new evidence, E062–E078)

| ID | Date | Source | What it establishes | Grade |
|---|---|---|---|---|
| E062 | 2026-11-13 | Pierce County 2025 Primary Voters' Pamphlet, p. 51 (PDF) — https://www.piercecountywa.gov/DocumentCenter/View/147377/2025-Primary-VP | Lindholm's official statement: “Seattle University School of Law (JD in progress)”; “University of Washington Tacoma (BA in progress)”; “Tacoma Prosecutor's Office; Puyallup Tribe of Indians”; endorsements | V text / S content |
| E063 | 2026-11-13 | Puyallup Tribal Court Courtesy Bar List, 2026-01-06 — https://www.puyalluptribe-nsn.gov/wp-content/uploads/Puyallup-Tribal-Court-Courtesy-Bar-List_2026.01.06.pdf | “Lindholm Philip M., … Advocate, Bar No. 585”; PO Box 39192; phone | V |
| E064 | 2026-11-13 | DVIDS, “Incoming Wing Chaplain eager to serve,” 2017-01-29 — https://www.dvidshub.net/news/221770/incoming-wing-chaplain-eager-serve | Rev. Dr. Philip Lindholm, incoming 194th Wing chaplain, Camp Murray | V |
| E065 | 2026-11-13 | The Cascadian, “About” — https://thecascadian.com/about/ | Co-founders Philip Lindholm and Walter Neary; 501(c)(3); editors Neary/Dunkelberger; PO Box 39192 | V |
| E066 | 2026-11-13 | The Seattle Times, Brier Dudley column — https://www.seattletimes.com/opinion/pierce-county-news-site-debuts-meta-starts-paying-for-news-and-more | “Neary started The Cascadian with Phil Lindholm”; outlet launched as an online bulletin board without original reporting | V |
| E067 | 2026-11-13 | ProPublica Nonprofit Explorer — https://projects.propublica.org/nonprofits/organizations/412787967 | Cascadian Media, 501(c)(3), EIN 41-2787967, Lakewood WA, NTEE A30; no 990 data | V |
| E068 | 2026-11-13 | HomeLight agent profile — https://www.homelight.com/agents/philip-lindholm-wa-109485 | Real Estate Agent at Terry Wise & Associates; 16 years; 50 transactions; $354K average; 44 single-family; 3.7/5 | C |
| E069 | 2026-11-13 | YouTube channel — https://www.youtube.com/@drphiliplindholm/about | 117K subscribers; 377 videos; 1,518,275 views; joined 2011-09-16 | V |
| E070 | 2026-11-13 | YouTube video description, The Informed Citizen — https://www.youtube.com/watch?v=hnRvCcKyOCs | “Produced in partnership with terrywisere.com”; “Editing & Post-Production: Tony Wise at wisevideography.com” | V |
| E071 | 2026-11-13 | Pierce County LINX, case 26-2-08192-7 — https://linxonline.co.pierce.wa.us/linxweb/Case/CivilCase.cfm?cause_num=26-2-08192-7 | *Lawrence v. Lindholm*; Consumer Protection Act; 62-page complaint; answer/amended answer; trial 2027-04-28 | V docket |
| E072 | 2026-11-13 | Pierce County LINX, case 18-2-07177-7 — https://linxonline.co.pierce.wa.us/linxweb/Case/CivilCase.cfm?cause_num=18-2-07177-7 | *Lindholm v. State Farm*; personal injury; settled by arbitration; dismissed with prejudice 2019 | V docket |
| E073 | 2026-11-13 | Pierce County LINX name searches, 2010–2026 | No Superior/District criminal, tax, or District civil cases for “Lindholm, Philip”; three “Lochburn” entity cases | V search result / U ownership |
| E074 | 2026-11-13 | LinkedIn profile — https://www.linkedin.com/in/drphiliplindholm | Certifications (broker 2011; chaplain 2019; mediator 2026); publications | S |
| E075 | 2026-11-13 | Official website: About, Education & Career, Public Service; Lakewood Chamber bio; News Tribune; Concord Counsel — https://www.philiplindholm.com/about; https://www.philiplindholm.com/education_and_career; https://www.philiplindholm.com/public_service; https://lakewood-chamber.org/members/city-of-lakewood-councilmember-philip-lindholm; https://www.thenewstribune.com/news/local/article310792280.html; https://www.concordcounsel.com | Biography, education, public service, business claims | S/C |
| E076 | 2026-11-13 | Wikipedia/DBpedia/Amazon author bio/AllMusic/Discogs — https://en.wikipedia.org/wiki/Philip_Lindholm; https://www.amazon.com/stores/author/B0050GEOE2/about; https://www.allmusic.com/artist/whiskey-n-rye-mn0003248720 | Early life, Oxford, BBC/ITV, books, music, chaplaincy | C/S |
| E077 | 2026-11-13 | The Cascadian columns — https://thecascadian.com/the-boy-on-the-bus; https://thecascadian.com/a-story-worth-telling/ | Columns; Playhouse Board; “mediator and Lakewood City Councilmember” | V |
| E078 | 2026-11-13 | YouTube transcripts, TEDx (4bGdzDkmCBs) and kickoff (_B24Q5tGei8) | TEDx chaplain narrative; kickoff speech (“my son,” downtown/homelessness/public safety) | V |

### Existing evidence

- E047–E061: PDC F-1s, ATIP parcel records, council packets/minutes, YouTube transcripts, PDC contribution data, PDC F-1 instructions. See `evidence-log.md`.
- E043: city ethics code / peer comparison (case file).
- E051–E058: Ordinance 849 and Solberg records.

---

## 14. One-paragraph summary for the desk

Philip Lindholm is not a simple small-city councilmember. He is an Oxford-trained Kierkegaard scholar, a former BBC/ITV documentary producer, an Air Force chaplain, a licensed real estate broker, an 84% owner of a Lakewood apartment complex listed as 18 units, a tribal-court advocate, a 117K-subscriber podcaster, and the co-founder of a new local news outlet that shares his campaign PO Box. Most of that portfolio is lawful and some of it is genuinely impressive. The accountability issue is **role density and disclosure**: the same person votes on rental-housing policy, abstains on an abatement contract involving his former employer's client, and runs a media platform produced in partnership with that employer's company. The public record shows a partial disclosure at the April 6 meeting, no disclosure at the May 4 rental-housing vote, and a pending Consumer Protection Act lawsuit filed by a Jacob Lawrence — the same name that appears on Lindholm's F-1 as a private note debtor; the identity link is unconfirmed. The story is not “crooked politician”; it is “how a part-time, nonpartisan city with no independent ethics board lets a very connected person's multiple roles blur — and what the public is entitled to know.” The next move is the complaint in *Lawrence v. Lindholm*, the PDC imaged F-1, and the expanded right-of-reply letter. [V facts; I frame]
