# F-1 Extract — Philip Lindholm, statement 132557
**Source:** WA PDC Financial Affairs Disclosures, Socrata dataset `ehbc-shxw`, record id 132557
**Filed:** 2026-03-23 · **Period:** 2025-01-01 to 2025-12-31 · **Filer ID:** LINDP--290
**URL:** https://my.pdc.wa.gov/financial-affairs/public/-/#/public/statement/132557

## Income reported
- University of Washington Medical Center — MEDICAL ASSISTANT — 0-29999
- OPM — Military — 30000-59999
- Defense Finance and Accounting Service — Military — 60000-99999
- VA — Military — 60000-99999

## Business associations (10%+ ownership or officer)
- **Wyoming Housing Holding Company** — operating name: Community for Philip Lindholm — Real Estate Activities — ownership: 100%
  - WA property: 107-109 Lake Louise Dr, Lakewood 98498
  - WA property: 9908 Meadow Rd. SW, Lakewood 98499
- **Washington Ventures Management** — operating name: Washington Ventures Management — Real Estate Activities — ownership: 100%
  - **Business customer payment:** Terry Wise & Associates — purpose: Consulting
- **8814-8815 Lochburn Lane SW Lakewood, LLC** — operating name: 8814-8815 Lochburn Lane SW Lakewood, LLC — Real Estate Activities — ownership: 84%
  - WA property: 8814-8815 Lochburn Lane SW, Lakewood 98499

## Real estate reported
- 107-109 Lake Louise Dr. SW, Lakewood — assessed 200000-499999 — sold: False
- 1223 S. J sT, Tacoma — assessed 1000000- — sold: True — purchaser: 1223 S J St LLC (1000000-)
- 705 S. 9th St. Suite 102, Tacoma — assessed 200000-499999 — sold: True — purchaser: Terry Wise (200000-499999)
- 520 Buena Vista Ave, Fircrest — assessed 200000-499999 — sold: True — purchaser: Andy Tran (200000-499999)
- 9908 Meadow Rd. SW, Lakewood — assessed 1000000- — sold: False
- 3025 S. Huson, Tacoma — assessed 30000-59999 — sold: False
- 8814-8815 Lochburn Lane SW, Lakewood — assessed 1000000- — sold: False

## Creditors reported
- Service Finance — unsecured credit line — $30,000–$59,999

## Note
The PDC instructions describe this section as 'Payments Received From Business Customers (>$12,000)': businesses that paid $12,000 or more in the aggregate for services or products provided by the entity. The public JSON does not show the exact payment date or amount; the filed form may. That is a right-of-reply question.