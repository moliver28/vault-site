<div id="main" class="report" role="main">

<div class="section stat-strip-wrap" aria-labelledby="spine-h">

<div class="stat-strip">

## The county in six numbers

- <div class="num">

  \$3.5B

  </div>

  <div class="lbl">

  Biennial budget, 2026–27. Adopted Nov 25, 2025; signed Dec 16.
  <sup>[\[E004\]](#src-05 "Source: evidence/05")</sup>

  </div>

- <div class="num">

  ~77%

  </div>

  <div class="lbl">

  Share of the General Fund spent on law enforcement and the courts.
  <sup>[\[E004\]](#src-05 "Source: evidence/05")</sup>

  </div>

- <div class="num">

  \$12.1B

  </div>

  <div class="lbl">

  JBLM economic impact — a *combined* Pierce + Thurston multiplier
  figure (Pierce-only direct output ≈ \$3.9B).
  <sup>[\[E009\]](#src-jblm "Source: SSMCP REIA 2023")</sup>
  <span class="chip corrected">corrected</span>

  </div>

- <div class="num">

  \$7.2B

  </div>

  <div class="lbl">

  MultiCare annual revenue, FY2025 (Fitch-confirmed).
  <sup>[\[E009\]](#src-multicare "Source: Fitch Ratings")</sup>

  </div>

- <div class="num">

  \$76B

  </div>

  <div class="lbl">

  Waterborne trade moved through the Northwest Seaport Alliance in 2024
  (~\$68B in 2025).
  <sup>[\[E009\]](#src-nwsa "Source: NWSA cargo statistics")</sup>

  </div>

- <div class="num">

  10.4M

  </div>

  <div class="lbl">

  Acres of U.S. timberland held by Weyerhaeuser — traceable to an 1864
  federal land grant.
  <sup>[\[E007\]](#src-weyer "Source: Weyerhaeuser IR")</sup>

  </div>

</div>

</div>

<div class="section" aria-labelledby="core-h">

Core finding

<div class="finding-hero">

<span class="interpretation-tag">Interpretation — labeled as such</span>

Pierce County’s major economic institutions derive substantial power
from **government-granted privileges** — federal appropriations, tax
exemption, tribal sovereignty, land grants, and public levies — and
these institutions in turn influence the government that grants those
privileges. This creates a structural interdependence that warrants
scrutiny.

That sentence is the thesis in the only form it survived hostile review.
The sharper versions considered earlier — that the county’s private
sector is “a government-created rentier class,” or that a “growth
machine” is a coordinated operation — were **rejected** in red-team
review as editorializing beyond the evidence. What the records do show
is the direction of the flows below, entity by entity, with sources.

<div class="loop-figure">

![](data:image/svg+xml;base64,PHN2ZyB2aWV3Ym94PSIwIDAgNTYwIDExOCIgd2lkdGg9IjU2MCIgaGVpZ2h0PSIxMTgiIHJvbGU9ImltZyIgYXJpYS1sYWJlbD0iTG9vcCBkaWFncmFtOiBHb3Zlcm5tZW50IGNyZWF0ZXMgd2VhbHRoOyBwcml2YXRlIGFjdG9ycyBjb252ZXJ0IGl0IHRvIHBvd2VyOyB0aGF0IHBvd2VyIHNoYXBlcyBwb2xpY3k7IHdoaWNoIHJldHVybnMgbW9yZSBtb25leS4iPgogICAgICAgICAgPGcgZm9udC1mYW1pbHk9Ii1hcHBsZS1zeXN0ZW0sIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTQiIGZvbnQtd2VpZ2h0PSI3MDAiPgogICAgICAgICAgICA8cmVjdCB4PSI4IiB5PSIxOCIgd2lkdGg9IjEyMCIgaGVpZ2h0PSI0MCIgcng9IjMiIGZpbGw9IiNCODg2MEIiIC8+CiAgICAgICAgICAgIDx0ZXh0IHg9IjY4IiB5PSI0MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZmlsbD0iI0ZGRjhFMSI+R292ZXJubWVudDwvdGV4dD4KICAgICAgICAgICAgPHJlY3QgeD0iMTgwIiB5PSIxOCIgd2lkdGg9IjExMCIgaGVpZ2h0PSI0MCIgcng9IjMiIGZpbGw9IiMxQjFCMUIiIC8+CiAgICAgICAgICAgIDx0ZXh0IHg9IjIzNSIgeT0iNDIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiNGQUZBRkEiPldlYWx0aDwvdGV4dD4KICAgICAgICAgICAgPHJlY3QgeD0iMzQyIiB5PSIxOCIgd2lkdGg9IjExMCIgaGVpZ2h0PSI0MCIgcng9IjMiIGZpbGw9IiMxQjFCMUIiIC8+CiAgICAgICAgICAgIDx0ZXh0IHg9IjM5NyIgeT0iNDIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiNGQUZBRkEiPlBvd2VyPC90ZXh0PgogICAgICAgICAgPC9nPgogICAgICAgICAgPGcgc3Ryb2tlPSIjOEE2QTBBIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiIG1hcmtlci1lbmQ9InVybCgjYXJyKSI+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik0xMjggMzggTDE3MiAzOCIgLz4KICAgICAgICAgICAgPHBhdGggZD0iTTI5MCAzOCBMMzM0IDM4IiAvPgogICAgICAgICAgICA8cGF0aCBkPSJNMzk3IDYwIEMgMzk3IDEwMiwgMjM1IDEwMiwgMjM1IDYwIiAvPgogICAgICAgICAgPC9nPgogICAgICAgICAgPGcgZm9udC1mYW1pbHk9Ii1hcHBsZS1zeXN0ZW0sIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTEiIGZpbGw9IiM1RDQwMzciPgogICAgICAgICAgICA8dGV4dCB4PSIxNTAiIHk9IjU0IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5ncmFudHM8L3RleHQ+CiAgICAgICAgICAgIDx0ZXh0IHg9IjMxMiIgeT0iNTQiIHRleHQtYW5jaG9yPSJtaWRkbGUiPmNvbnZlcnRzPC90ZXh0PgogICAgICAgICAgICA8dGV4dCB4PSIzMTYiIHk9IjExMiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+c2hhcGVzIHBvbGljeSDigJQgbW9yZSBtb25leSByZXR1cm5zPC90ZXh0PgogICAgICAgICAgPC9nPgogICAgICAgICAgPGRlZnM+CiAgICAgICAgICAgIDxtYXJrZXIgaWQ9ImFyciIgdmlld2JveD0iMCAwIDEwIDEwIiByZWZ4PSI5IiByZWZ5PSI1IiBtYXJrZXJ3aWR0aD0iNyIgbWFya2VyaGVpZ2h0PSI3IiBvcmllbnQ9ImF1dG8tc3RhcnQtcmV2ZXJzZSI+CiAgICAgICAgICAgICAgPHBhdGggZD0iTTAgMCBMMTAgNSBMMCAxMCB6IiBmaWxsPSIjOEE2QTBBIiAvPgogICAgICAgICAgICA8L21hcmtlcj4KICAgICAgICAgIDwvZGVmcz4KICAgICAgICA8L3N2Zz4=)

The loop as a frame, not a finding: each arrow above is documented for
the six institutions below; the loop *as a system* is the
investigation’s interpretation.

</div>

</div>

</div>

<div class="section" aria-labelledby="money-h">

Where the economic power comes from

## Six anchors, one shared pattern

For each of the county’s six major economic institutions, researchers
traced the origin of the economic base. Every anchor draws on a
government-granted advantage; the pattern held in all six cases and is
the most heavily verified part of this investigation.

<div class="tbl-wrap">

| Institution | What it holds | Government-granted basis | Verified figure | Grade |
|----|----|----|----|----|
| **JBLM** (Joint Base Lewis-McChord) | Largest employer; I Corps HQ; ~90,000-acre federal installation | 100% federal appropriations, payroll, and contracts | \$12.1B impact<span class="basis">Pierce + Thurston combined multiplier; Pierce-only direct output ≈ \$3.9B</span> | <span class="chip verified">verified</span> |
| **MultiCare** Health System | Nonprofit hospital system; largest private employer (widely stated; no single authoritative Pierce-only headcount is published) | 501(c)(3) tax exemption since 1991; Medicare/Medicaid are the largest payers; government-regulated insurance market | \$7.2B revenue<span class="basis">FY2025, per Fitch; 22,789 employees per IRS 990 FY2024</span> | <span class="chip verified">verified</span> |
| **Puyallup Tribe of Indians** | Sovereign nation; Emerald Queen Casino; land into trust | Federal recognition; 1854 Treaty of Medicine Creek; gaming compact with the state; 1990 settlement returned land | \$162M settlement<span class="basis">1990 land-claims settlement (\$162M + 900 acres) — a settlement figure, not current assets</span> | <span class="chip verified">verified</span> <span class="chip corrected">corrected</span> |
| **Weyerhaeuser** | Largest private U.S. timberland owner | Fortune traceable to the 1864 Northern Pacific land grant; bought 900,000 acres from the railroad in 1900 at \$6/acre (\$5.4M) | 10.4M acres<span class="basis">U.S. holdings today (company report, Oct 2025)</span> | <span class="chip verified">verified</span> |
| **Port of Tacoma** | Container terminals; Tideflats land; NWSA co-owner | Public municipal corporation under RCW Title 53, partly funded by a property-tax levy (\$25.3M in 2023, rising to \$28.5M by 2027) | \$76B cargo<span class="basis">NWSA waterborne trade, 2024 (~\$68B in 2025)</span> | <span class="chip verified">verified</span> |
| **Tacoma-Pierce County Chamber** | Business league, founded 1884; ~1,400 members; 25-member board | Tax-exempt 501(c)(6) | \$3.08M revenue<span class="basis">FY2024, IRS 990 via ProPublica</span> | <span class="chip verified">verified</span> |

</div>

Figures, bases, and sources as recorded in the case’s money map
(*evidence/28-source-of-economic-power.md*), each tied to a primary
document. [Full source list.](#sources)

</div>

<div class="section" aria-labelledby="rank-h">

The top of the map

## The ten most powerful actors

The ranking below is the investigation’s **qualitative matrix** — scored
across six domains (government, economic, institutional, political,
legal, media) by the evidence. The interactive graph ([Method](#method))
computes its own network ranking separately; a network-centrality score
is not treated here as a settled measure of power.

1.  <span class="dot" style="background:var(--d-government)"></span>Ryan
    Mello

    Pierce County Executive (D, since Jan 2025)

    Runs the county’s departments and holds veto power over the Council.
    Controls the \$3.5B biennial budget. Elected 51.28%–48.58% (209,918
    to 198,886 votes) — a narrow mandate. Former GTCF board member;
    Sound Transit board vice chair. <sup>[\[E001\]](#src-01)</sup> In
    active conflict with Sheriff Swank over authority.

    <span class="chip verified">verified</span>

2.  <span class="dot"
    style="background:var(--d-government)"></span>Pierce County Council

    7 members, 4 D – 3 R · Chair Jani Hitchen (D-6), Vice Chair Dave
    Morell (R-1)

    Final say over the budget, zoning and land use, contracts, and
    appointments — the body every county actor must come to. The most
    connected node in the network graph. <sup>[\[E001\]](#src-01)</sup>

    <span class="chip verified">verified</span>

3.  <span class="dot"
    style="background:var(--d-institutional)"></span>Puyallup Tribe of
    Indians

    Federally recognized sovereign nation · ~4,000 enrolled members

    The only actor that can opt out of county jurisdiction. Gaming,
    land-into-trust authority, and a binding land-use consultation
    process (LUCP) with local governments. Bill Sterud has served on
    tribal council since 1978 — the chairmanship *rotates annually*
    (Sterud and David Z. Bean have alternated; the map’s static
    “chairman” label was corrected in review). Donates to candidates of
    both parties. <sup>[\[E003, E009\]](#src-tribe)</sup>

    <span class="chip verified">verified</span>
    <span class="chip corrected">corrected</span>

4.  <span class="dot"
    style="background:var(--d-institutional)"></span>MultiCare Health
    System

    Nonprofit hospital system, headquartered in Tacoma

    \$7.2B revenue (FY2025); 22,789 employees per its latest IRS 990;
    largest private employer (widely stated — no authoritative
    Pierce-only headcount exists). Board chair John Wiborg links it to
    the Chamber, GTCF, and UW Tacoma. CEO Bill Robertson retires Dec
    2026; Florence Chang takes over Jan 2027. <sup>[\[E008,
    E009\]](#src-multicare)</sup>

    <span class="chip verified">verified</span>

5.  <span class="dot"
    style="background:var(--d-institutional)"></span>Joint Base
    Lewis-McChord

    U.S. Army/Air Force installation · I Corps HQ

    57,000+ direct jobs; the county’s largest employer. Its influence is
    structural: federal land outside local control, coordinated with
    local governments through SSMCP, and economic impact (Pierce +
    Thurston combined ≈ \$12.1B, Pierce-only direct ≈ \$3.9B) that could
    be cut or moved by Congress. <sup>[\[E009\]](#src-jblm)</sup>

    <span class="chip verified">verified</span>
    <span class="chip corrected">corrected</span>

6.  <span class="dot" style="background:var(--d-government)"></span>Port
    of Tacoma

    Independent municipal corporation · 5 countywide-elected
    commissioners

    A public agency, not private capital: property-tax levy funding,
    \$353.7M capital budget, and shared control (with the Port of
    Seattle) of the Northwest Seaport Alliance’s \$76B annual cargo.
    Commissioner John McCarthy has served 40 years across 4 terms.
    <sup>[\[E001, E009\]](#src-port)</sup>

    <span class="chip verified">verified</span>

7.  <span class="dot"
    style="background:var(--d-government)"></span>Keith Swank

    Pierce County Sheriff (since Jan 2025) · 33-year Seattle PD veteran

    Elected independently of the Executive — cannot be fired by them.
    Controls \$406M across law enforcement (\$242.2M) and the jail
    (\$164.3M), 42% of the county’s General Fund. His power is
    concentrated in one domain, and he is in open conflict with both the
    Executive and the Prosecuting Attorney. <sup>[\[E001,
    E004\]](#src-01)</sup>

    <span class="chip verified">verified</span>

8.  <span class="dot" style="background:var(--d-government)"></span>Mary
    Robnett

    Pierce County Prosecuting Attorney (since 2019) · first woman in the
    office

    Charges every felony in a county of ~900,000; her civil division
    advises all county departments. Unopposed since 2018; not seeking
    re-election in 2026. Feuding with the Sheriff’s office over
    representation. <sup>[\[E001\]](#src-01)</sup>

    <span class="chip verified">verified</span>

9.  <span class="dot" style="background:var(--d-government)"></span>Jani
    Hitchen

    Council Chair, District 6 (Steilacoom, DuPont, JBLM, Lakewood)

    Sets the Council’s legislative agenda and appoints committee chairs.
    Her district makes her the council’s direct interface with JBLM.
    <sup>[\[E001\]](#src-01)</sup>

    <span class="chip verified">verified</span>

10. <span class="dot" style="background:var(--d-political)"></span>Kelly
    Chambers

    State Representative (R-25) · 2024 county executive candidate

    The GOP’s best-funded candidate: \$549,574 raised for the executive
    race, including a single \$175,500 transfer from the Pierce County
    Republican Party — the largest check documented in the 2024 cycle.
    Her donor list is heavily auto-dealer, developer, and real-estate
    money (documented donations; no motive asserted). Holds no county
    office. <sup>[\[E004\]](#src-pdc)</sup>

    <span class="chip verified">verified</span>

</div>

<div class="section" aria-labelledby="find-h">

Findings

## Five findings, strongest first

<div class="finding">

### 1. One office controls the county’s money — and holds a veto over its legislature.

The Executive proposes and signs the \$3.5B biennial budget and can veto
Council legislation; the Council appropriates it. Roughly 77% of the
General Fund goes to law enforcement and the courts, so the elected
Sheriff (\$406M) and Prosecuting Attorney (\$94.1M) sit at the center of
county spending even as they answer to voters, not the Executive. County
power concentrates in offices that cannot easily be overridden.
<sup>[\[E001, E004\]](#src-05)</sup>

</div>

<div class="finding">

### 2. All six major economic anchors rest on government-granted advantages.

Federal appropriations fund JBLM outright; tax exemption (plus
Medicare/Medicaid reimbursement) underlies MultiCare’s \$7.2B; federal
recognition and a state gaming compact underlie the Tribe’s casino
economy; Weyerhaeuser’s acreage traces to an 1864 land grant sold once,
cheaply, to a railroad; the Port is a public taxing entity; the Chamber
is tax-exempt. This is the finding that survived every hostile check,
entity by entity, with primary documents. <sup>[\[E007,
E009\]](#src-jblm)</sup>

</div>

<div class="finding">

### 3. The same few people sit on both sides of the table.

Three documented dual roles anchor the interlock pattern: the Chamber’s
CEO, Tom Pierson, was also appointed the county’s acting
economic-development director; MultiCare’s board chair, John Wiborg,
sits on the Chamber board and is a former GTCF board member; labor’s
Nathe Lawver chairs United Way of Pierce County while sitting on both
the GTCF and Economic Development Board. Ryan Mello himself is a former
GTCF board member now holding the executive’s office. These are
documented overlaps — the records show who shares tables, not what
happens at them. <sup>[\[E008, E010\]](#src-interlock)</sup>

</div>

<div class="finding">

### 4. Party money is lopsided; tribal money is bipartisan.

In the 2024 executive race, both finalists raised over half a million
dollars (\$509,801 for Mello; \$549,574 for Chambers). The Republican
money was concentrated — one \$175,500 check from the county party plus
\$28,500-class transfers from caucus committees; the Democratic money
was broader — unions (UFCW, IBEW 483, IAFF 726, WEA PAC), the HDCC
(\$28,500), and individual donors. The Puyallup Tribe gave to both
parties (\$2,400 to Mello among others) — documented donations from a
sovereign actor with land-use business before the same governments. The
report asserts the flows, not any exchange.
<sup>[\[E004\]](#src-pdc)</sup>

</div>

<div class="finding">

### 5. The county’s only daily newspaper is owned by an out-of-state hedge fund.

The News Tribune’s parent, McClatchy, is owned by Chatham Asset
Management (NJ) — acquired in bankruptcy in 2020 through a ~\$312M
credit bid plus \$49M cash. Its editor, Stephanie Pedersen, edits four
McClatchy papers at once; the AP wire was dropped in 2024; the county
has no locally owned TV station. Narrative capacity is real but
*extracted*: what gets covered locally is decided two time zones away.
<sup>[\[E006\]](#src-media)</sup>

</div>

</div>

<div class="section" aria-labelledby="il-h">

The interlock economy

## Who sits on both sides

The map’s densest short paths run through a handful of people who bridge
government, business, philanthropy, and labor. Each role below is
independently sourced.

<div class="interlock">

### Tom Pierson

Interim CEO, Tacoma-Pierce County Chamber · Acting Director of Economic
Development, Pierce County

Confirmed in red-team review as a live revolving door: the same person
leads the business lobby and the county office that hands out
economic-development support. Sourced to chamber and county records plus
his professional profile. <sup>[\[E009\]](#src-interlock)</sup>

</div>

<div class="interlock">

### John Wiborg

Board Chair, MultiCare · CEO, Stellar Industrial Supply · Chamber board
· former GTCF board · UW Tacoma honorand

Connects the hospital system to the business lobby and community
philanthropy. He is the node that ties health money to the establishment
network. <sup>[\[E008\]](#src-interlock)</sup>

</div>

<div class="interlock">

### Nathe Lawver

Board Chair, United Way of Pierce County · GTCF board · Executive
Secretary, Pierce County Building & Construction Trades Council · EDB
board · UFCW Local 367

Verified as the true GTCF–United Way interlock (an earlier profile
attributed that tie to Dona Ponepinto; review corrected it). He bridges
labor, philanthropy, and economic development at once.
<sup>[\[E009\]](#src-interlock)</sup>
<span class="chip corrected">corrected</span>

</div>

<div class="interlock">

### Ryan Mello

County Executive · former GTCF board · Sound Transit board vice chair ·
Pierce Transit board

The highest-arc bridge in the map: philanthropy to regional transit to
the executive’s office. Listed here as documented former and current
roles. <sup>[\[E013\]](#src-interlock)</sup>

</div>

</div>

<div class="section" aria-labelledby="media-h">

Narrative power

## One daily paper, owned elsewhere

Ownership chain of the only daily: **Chatham Asset Management (NJ)** →
**McClatchy Media Company** → **The News Tribune** (Tacoma; founded
1880; locally owned by the Baker family for 73 years until McClatchy
bought it in 1986 for ~\$112M). Around it: three radio groups, one
business weekly, a weekly paper — and zero locally owned TV. The editor
edits four papers at once; the opinion editor was appointed in 2025. In
a county where the Port, the Tribe, MultiCare, and the Council all
generate daily coverage decisions, the outlet that frames them is not
locally owned. <sup>[\[E006\]](#src-media)</sup>

</div>

<div class="section" aria-labelledby="lim-h">

What this map cannot say

## Limits, open to the reader

<div class="limits-card">

- **The computed power score is a network measure, not a power
  measure.** Graph centrality over-counts connected hubs (parties, the
  Council, courts) and under-counts isolated veto-holders (the Tribe,
  JBLM, the Sheriff). That is why this report uses the qualitative
  matrix and tier bands instead of raw scores.
- **“Shadow political party” is a characterization, not a finding.** The
  Chamber’s Candidate Academy, Voters Guide, and Candidates Forum are
  documented; it officially does not endorse candidates. This report
  describes the programs and stops there.
- **The “growth machine” is an academic lens, not a proven
  organization.** Donor flows between developers, realtors, banks, and
  the Chamber are documented; coordinated direction is not.
- **Two numbers failed verification and appear nowhere above:** the
  MultiCare-linked “\$357K against Democrats in 2022” figure (actually
  attributed to the hospital association’s PAC, unconfirmed against PDC
  C4 reports) and the claim that the Tribe is the county’s *largest*
  lobbying spender (federal lobbying of \$270K in 2024 is verified; the
  superlative is not).
- **Corrections carried into this report:** JBLM’s \$12.1B is a
  two-county multiplier; the Tribe’s \$162M is a 1990 settlement, not
  current assets; the tribal chairmanship rotates annually; the council
  appropriates *to* the sheriff, courts, and prosecutor (edge directions
  were reversed in an earlier draft); Kastama sits on Puyallup’s city
  council, not the county council; T’wina Nobles sits on the University
  Place school board.
- **Not yet checked:** current council committee chairs for the 2026
  session; Swank’s early biography details; a Pierce-only authoritative
  MultiCare headcount.

</div>

</div>

<div class="section" aria-labelledby="ror-h">

Right of reply

## Comment status

<div class="ror-card">

**No formal right-of-reply requests have been sent as of this report.**
Every figure here comes from public records — election filings, IRS
990s, .gov budget documents, court and corporate registries — and
describes offices, grants, donations, and board seats rather than
private conduct.

Before any public-facing edition, the investigation intends to request
comment from the named subjects: the County Executive, Sheriff,
Prosecuting Attorney, Council members, the Port, the Tribe’s information
office, MultiCare, VMFH, the Chamber, Weyerhaeuser, McClatchy, and the
individuals named in the interlock section. This section will record
each request and response — or a plain “did not respond” — when
publication nears.

</div>

</div>

<div id="method" class="section" aria-labelledby="method-h">

Methodology

## How this was built, and verified

Researchers mapped 163 entities across six domains — government (53),
institutional (47), economic (32), political (17), media (8), legal (6)
— and recorded 342 relationships, each with a typed label (board seats,
funding, donations, lobbying, ownership) and a weight. Then the work was
attacked:

1.  **Hypercritical audit** (E008) — every node, edge, and ranking
    checked against the evidence files; 12 wrong edges, 12 filler edges,
    and 45 missing entities found and fixed.
2.  **Red-team review** (E009) — every claim assumed wrong until a
    primary source (.gov, WA PDC, IRS 990s, Fitch, court records)
    confirmed it; ~80% survived, and every mischaracterized figure was
    corrected.
3.  **Three skeptic subagents** (E010) — ranked the ranking, the
    omissions, and the money separately, catching the Council over-rank,
    Kelly Chambers’ inflated score, the buried Tacoma mayor, and the
    wrong Chamber budget (\$4.5M → \$3.08M).
4.  **Deep profiles** (E013–E014) — all 163 entities researched against
    primary sources, 43 new edges, deterministic consistency sync (272 →
    342 edge count), with per-entity confidence ratings.

Composite scores blend six domains; the interactive graph adds a
veto-power bonus for actors whose influence is concentrated and
non-negotiable (the Tribe, JBLM, the Sheriff, the Chamber) rather than
distributed. Full method: *evidence/26-power-methodology.md*.

</div>

<div class="section" aria-labelledby="explore-h">

Explore the full map

## The interactive network

This report is the read-mode summary. The full artifact — all 163
entities with 14-section deep profiles, ego-networks, the “Follow the
money” toggle that isolates the government-granted wealth edges, and the
tier-band directory — ships as the case’s interactive power network:

**[→ Open the Pierce County Power Network (interactive,
offline-capable)](network/index.html)** · Raw data:
*evidence/29-power-graph-v2.json* & *evidence/30-power-graph-v3.json*

</div>

</div>
