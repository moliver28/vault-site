<div class="shell" role="main">

<div id="map-pane" class="section" aria-label="Power network map">

<div id="svg-host">

</div>

<div id="map-toolbar">

Follow the money

</div>

<div id="map-legend" class="map-legend" aria-label="Map legend">

</div>

</div>

<div id="directory" class="aside" aria-label="Entity directory"
tabindex="-1">

<div id="mission-strip" role="status">

</div>

<div class="dir-controls">

Search 163 entities

<div id="domain-chips" class="chip-row" aria-label="Filter by domain">

</div>

<div id="tier-chips" class="chip-row" aria-label="Filter by tier band">

</div>

<span id="sort-status" class="visually-hidden"
aria-live="polite"></span>

</div>

<div class="table-scroll">

| Rank | Name | Tier | Domain |
|------|------|------|--------|

</div>

</div>

</div>
